---
name: mental-health
description: User's mental health treatment, medication, and dietary restrictions
---

User's psychiatrist started them on sertraline for depression two weeks ago. It makes them really groggy in the mornings. User is off alcohol while on antidepressants. User is lactose intolerant.
