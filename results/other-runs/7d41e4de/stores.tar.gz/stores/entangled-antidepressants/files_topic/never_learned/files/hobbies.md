---
name: hobbies
description: User's interest in running and target event, including their dog Biscuit and Biscuit's vet appointment
---

User wants to get back into running. User's target is the Sundown Marathon 5K category in late May. User has moved their runs to 7pm. User has a dog named Biscuit who is confused by the new running schedule. Biscuit's vet appointment is Thursday at 5pm.
