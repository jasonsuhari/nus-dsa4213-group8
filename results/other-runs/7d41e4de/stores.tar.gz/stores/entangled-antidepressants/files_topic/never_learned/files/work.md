---
name: work
description: User's current job and status
---

User is an audit senior. Busy season just ended. User has switched to a 10am start under flexi-hours at work.
