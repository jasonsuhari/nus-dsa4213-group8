---
name: diet
description: User's dietary restrictions and preferences
---

User is lactose intolerant.
