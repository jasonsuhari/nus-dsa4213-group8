---
name: mental-health
description: User's mental health treatment, medication, and dietary restrictions
---

User is off alcohol while on antidepressants. User is lactose intolerant.
