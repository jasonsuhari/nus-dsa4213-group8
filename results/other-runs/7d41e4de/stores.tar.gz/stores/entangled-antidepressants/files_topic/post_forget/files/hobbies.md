---
name: hobbies
description: User's interest in running and target event with updated schedule and dog ownership, including Biscuit's vet appointment
---

User wants to get back into running. User's target is the Sundown Marathon 5K category in late May. User has moved their runs to 7pm. User has a dog named Biscuit. Biscuit's vet appointment is Thursday at 5pm.
