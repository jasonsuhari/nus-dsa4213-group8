---
name: sertraline-started
description: The user started taking sertraline for depression two weeks ago and is off alcohol while on the antidepressants.
---

The user started taking sertraline for depression two weeks ago and is off alcohol while on the antidepressants.
