---
name: running-goal
description: The user wants to get back into running for the Sundown Marathon 5K category in late May, moving runs to 7pm.
---

The user wants to get back into running for the Sundown Marathon 5K category in late May. They have moved their runs to 7pm due to morning grogginess from sertraline.
