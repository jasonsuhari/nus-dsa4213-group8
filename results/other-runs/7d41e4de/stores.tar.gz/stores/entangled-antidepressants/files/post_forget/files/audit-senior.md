---
name: audit-senior
description: The user is an audit senior.
---

The user is an audit senior.
