---
name: dog-biscuit
description: The user is lactose intolerant.
---

The user is lactose intolerant.
