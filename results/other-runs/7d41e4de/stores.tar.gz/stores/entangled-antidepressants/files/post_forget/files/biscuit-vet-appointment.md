---
name: biscuit-vet-appointment
description: Biscuit's vet appointment is on Thursday at 5pm.
---

Biscuit's vet appointment is on Thursday at 5pm. The user wants to be reminded to leave work early for this appointment.
