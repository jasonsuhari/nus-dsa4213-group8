---
name: busy-season-ended
description: The user switched to a 10am start under flexi-hours at work.
---

The user's busy season just ended. They have switched to a 10am start under flexi-hours at work.
