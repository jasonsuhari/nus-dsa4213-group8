---
name: audit-senior
description: The user has switched to a 10am start under flexi-hours at work.
---

The user is an audit senior and has switched to a 10am start under flexi-hours at work.
