---
name: busy-season-ended
description: The user has a vet appointment for Biscuit on Thursday at 5pm and wants to be reminded to leave work early.
---

The user has a vet appointment for Biscuit on Thursday at 5pm and wants to be reminded to leave work early.
