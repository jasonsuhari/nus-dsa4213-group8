---
name: running-goal
description: The user wants to get back into running for the Sundown Marathon 5K category in late May and has moved their runs to 7pm.
---

The user wants to get back into running for the Sundown Marathon 5K category in late May and has moved their runs to 7pm.
