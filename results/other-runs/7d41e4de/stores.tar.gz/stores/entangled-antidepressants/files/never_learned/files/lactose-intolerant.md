---
name: lactose-intolerant
description: The user is lactose intolerant.
---

The user is lactose intolerant.
