---
name: exercise
description: User's exercise routine and activities, including post-exercise habits.
---

The user does tai chi every morning at Bishan Park with their kakis at 7am. After tai chi, the user goes to kopitiam.
