---
name: malacca-trip
description: User's planned trip to Malacca with mahjong kakis, including food preferences.
---

The user plans to go to Malacca for a weekend in September with their mahjong kakis. The user will eat chicken rice balls while in Malacca.
