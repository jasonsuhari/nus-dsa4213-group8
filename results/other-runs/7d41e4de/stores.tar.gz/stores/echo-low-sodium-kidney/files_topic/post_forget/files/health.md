---
name: health
description: Health information regarding the user's kidney disease, dietary restrictions, and medical check-ups.
---

The user has stage 3 kidney disease. The user likes hawker food, including wanton mee, laksa, and chicken rice. The user will have a reunion dinner at their daughter's house in Toa Payoh for Chinese New Year. The user has blood tests every 3 months at the polyclinic. The user's next blood test is on 23 June.
