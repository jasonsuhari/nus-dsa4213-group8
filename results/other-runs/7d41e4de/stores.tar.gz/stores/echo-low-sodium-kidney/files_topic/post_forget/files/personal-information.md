---
name: personal-information
description: Basic personal information about the user, including family details and social activities.
---

The user is Mr Lim. The user is a retired teacher. The user has a daughter who lives in Toa Payoh. The user has a grandson named Jayden who is 8 years old. The user has mahjong kakis.
