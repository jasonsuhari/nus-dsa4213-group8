---
name: health
description: User's health-related information including medical tests and reminders.
---

The user has a blood test every 3 months at the polyclinic. The user's next blood test is on 23 June. The user needs to fast from midnight on 22 June before the blood test.
