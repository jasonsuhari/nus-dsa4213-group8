---
name: personal-information
description: Basic personal information about the user, including food preferences and family events.
---

The user is Mr Lim. The user is a retired teacher. The user likes hawker food, including wanton mee, laksa, and chicken rice. The user has a daughter. The user has a grandson named Jayden who is 8 years old. The user will have a reunion dinner at his daughter's house in Toa Payoh for Chinese New Year next week.
