---
name: mahjong-kakis
description: User's mahjong group and related activities.
---

The user has mahjong kakis. The user plans to go to Malacca for a weekend in September with his mahjong kakis.
