---
name: exercise-routine
description: User's exercise routine including tai chi and post-exercise activities.
---

The user does tai chi every morning at Bishan Park with his kakis at 7am. After tai chi, the user goes to a kopitiam.
