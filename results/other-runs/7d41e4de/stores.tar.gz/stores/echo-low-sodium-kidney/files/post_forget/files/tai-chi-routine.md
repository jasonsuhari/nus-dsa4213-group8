---
name: tai-chi-routine
description: User does tai chi every morning at Bishan Park with his kakis at 7am and goes to kopitiam afterwards.
---

The user does tai chi every morning at Bishan Park with his kakis at 7am and goes to kopitiam afterwards.
