---
name: chinese-new-year
description: User's plans for Chinese New Year
---

Chinese New Year is next week. The user will have a reunion dinner at their daughter's house in Toa Payoh. The user's grandson Jayden, who is 8 years old, wants to give the user a red packet he saved.
