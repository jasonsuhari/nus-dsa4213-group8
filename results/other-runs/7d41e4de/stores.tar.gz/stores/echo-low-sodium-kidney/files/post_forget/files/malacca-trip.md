---
name: malacca-trip
description: User's plans to go to Malacca with mahjong kakis
---

The user plans to go to Malacca for a weekend in September with his mahjong kakis. The user will eat chicken rice balls there.
