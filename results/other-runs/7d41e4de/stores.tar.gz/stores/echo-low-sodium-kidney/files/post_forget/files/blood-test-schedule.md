---
name: blood-test-schedule
description: User has a blood test every 3 months at the polyclinic
---

The user has a blood test every 3 months at the polyclinic. The next one is on 23 June.
