---
name: son-setup-app
description: User's son set up the app for him
---

The user's son set up this app for him.
