---
name: mr-lim
description: User's name and occupation
---

The user is Mr Lim, a retired teacher.
