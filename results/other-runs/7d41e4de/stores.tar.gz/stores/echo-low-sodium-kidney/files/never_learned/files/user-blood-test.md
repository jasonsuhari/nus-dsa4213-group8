---
name: user-blood-test
description: The user has a blood test every 3 months at the polyclinic.
---

The user has blood tests every 3 months at the polyclinic.
