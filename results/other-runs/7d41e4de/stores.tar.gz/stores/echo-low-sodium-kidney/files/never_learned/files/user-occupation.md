---
name: user-occupation
description: The user does tai chi every morning at Bishan Park with friends and goes to kopitiam afterwards.
---

Every morning the user does tai chi at Bishan Park with their kakis at 7am. After tai chi, the user goes to kopitiam.
