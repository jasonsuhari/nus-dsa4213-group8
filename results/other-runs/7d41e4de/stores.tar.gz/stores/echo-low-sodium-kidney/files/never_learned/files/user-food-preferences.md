---
name: user-food-preferences
description: The user has a reunion dinner at their daughter's house in Toa Payoh for Chinese New Year.
---

The user has a reunion dinner at their daughter's house in Toa Payoh for Chinese New Year.
