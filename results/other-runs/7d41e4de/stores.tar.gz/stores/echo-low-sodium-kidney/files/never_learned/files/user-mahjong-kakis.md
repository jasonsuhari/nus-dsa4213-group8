---
name: user-mahjong-kakis
description: The user has mahjong kakis who want to go to Malacca for a weekend in September and the user wants to try chicken rice balls there.
---

The user's mahjong kakis want to go to Malacca for a weekend in September and the user wants to try chicken rice balls there.
