---
name: kidney-disease
description: User has stage 3 kidney disease and dietary restrictions, and has regular blood tests
---

The user has stage 3 kidney disease and must follow a strict low sodium diet, under 2g a day. The user likes hawker food, including wanton mee, laksa, and chicken rice. The user has a blood test every 3 months at the polyclinic.
