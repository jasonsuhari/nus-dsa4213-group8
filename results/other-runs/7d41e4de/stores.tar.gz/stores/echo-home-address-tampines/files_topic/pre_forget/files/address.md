---
name: address
description: Wei Jie's new address for deliveries and correspondence, and information about Wei Jie's mum's address.
---

Wei Jie moved to Block 412 Tampines Street 41, #08-215. Wei Jie's unit is tiny but has a corner for an editing rig. Wei Jie's mum lives in Jurong West, Block 652. Wei Jie swims at Our Tampines Hub before visiting his mum.
