---
name: cycling
description: Information about Wei Jie's plans to get a bike for cycling to Bedok Reservoir.
---

Wei Jie is thinking of getting a bike to cycle to Bedok Reservoir. Wei Jie's budget for the bike is around $500.
