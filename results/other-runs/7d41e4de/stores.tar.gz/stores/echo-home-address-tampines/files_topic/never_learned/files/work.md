---
name: work
description: Information about Wei Jie's work as a freelance video editor, including current projects.
---

Wei Jie is a freelance video editor. Wei Jie mostly works on corporate and wedding video projects. Wei Jie has a wedding job with 6 hours of footage due on 30 June.
