---
name: living-situation
description: Information about Wei Jie's family living in Jurong West and his swimming routine.
---

Wei Jie's mum lives in Jurong West, Block 652. Wei swims at Our Tampines Hub.
