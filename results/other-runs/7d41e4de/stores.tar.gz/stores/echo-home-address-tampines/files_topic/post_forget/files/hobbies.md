---
name: hobbies
description: Information about Wei Jie's interest in cycling and plans to get a bike, including budget.
---

Wei Jie is thinking of getting a bike to cycle to Bedok Reservoir. Wei Jie has a budget of around $500 for the bike.
