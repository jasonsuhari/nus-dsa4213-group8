---
name: work
description: Information about Wei Jie's work as a freelance video editor and recent purchase, including details about a wedding job.
---

Wei Jie is a freelance video editor. Wei Jie mostly works on corporate and wedding video projects. Wei Jie ordered a PAX wardrobe from IKEA, which is 150cm wide. Wei Jie has a wedding job with 6 hours of footage due on 30 June.
