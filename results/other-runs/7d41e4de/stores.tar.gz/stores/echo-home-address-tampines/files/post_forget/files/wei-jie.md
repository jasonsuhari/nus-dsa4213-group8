---
name: wei-jie
description: User's name, profession, and current project details
---

The user is Wei Jie, a freelance video editor, mostly working on corporate and wedding projects. The user is currently working on a wedding job that involves 6 hours of footage, due on 30 June. The user is ordering a PAX wardrobe from IKEA.
