---
name: user-bike
description: User is considering getting a bike to cycle to Bedok Reservoir with a budget.
---

The user is thinking of getting a bike to cycle to Bedok Reservoir. The user's budget for the bike is around $500.
