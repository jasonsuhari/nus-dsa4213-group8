---
name: user-address
description: User's new address for deliveries
---

The user has moved to . The unit is tiny but has a corner for the user's editing rig. The user's address for deliveries is , Singapore . The user is ordering a PAX wardrobe, 150cm wide.
