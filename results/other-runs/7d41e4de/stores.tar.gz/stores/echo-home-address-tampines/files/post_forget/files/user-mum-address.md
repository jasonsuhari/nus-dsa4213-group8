---
name: user-mum-address
description: User's swimming location before visiting mother
---

The user swims at Our Tampines Hub before visiting their mother.
