---
name: wedding-job
description: User has a wedding job with 6 hours of footage due on 30 June.
---

The user has a wedding job with 6 hours of footage due on 30 June.
