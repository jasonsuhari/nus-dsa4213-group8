---
name: user-bike
description: User is considering getting a bike to cycle to Bedok Reservoir
---

The user is thinking of getting a bike to cycle to Bedok Reservoir. Their budget is around $500.
