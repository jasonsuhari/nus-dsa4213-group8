---
name: wei-jie
description: User's name, profession, and living situation
---

The user is Wei Jie, a freelance video editor, mostly working on corporate and wedding projects. The user just moved to a new place with a tiny unit but has a corner for their editing rig.
