---
name: pax-wardrobe
description: User is ordering a PAX wardrobe from IKEA Tampines
---

The user is ordering the PAX wardrobe from IKEA Tampines, 150cm wide.
