---
name: user-mum-address
description: User's mother's address in Jurong West
---

The user's mother lives in Jurong West, Block 652. The user swims at Our Tampines Hub before visiting their mother.
