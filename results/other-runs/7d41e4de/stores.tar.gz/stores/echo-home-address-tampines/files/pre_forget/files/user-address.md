---
name: user-address
description: User's new address for deliveries
---

The user has moved to Block 412 Tampines Street 41, #08-215. The unit is tiny but has a corner for the user's editing rig. The user's address for deliveries is Blk 412 Tampines St 41, #08-215, Singapore 520412. The user is ordering a PAX wardrobe, 150cm wide.
