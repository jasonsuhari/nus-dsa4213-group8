---
name: ntus-lectures
description: User's upcoming thermodynamics midterm and chess club tournament
---

Hakim's thermodynamics midterm is on 4 March 2026. Hakim is participating in a rapid chess tournament on 7 March 2026 at Jurong West CC.
