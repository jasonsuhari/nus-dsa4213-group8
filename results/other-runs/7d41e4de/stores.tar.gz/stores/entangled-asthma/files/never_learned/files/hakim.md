---
name: hakim
description: User's participation in an indoor rowing challenge
---

Hakim is skipping the hall's cross-country run on 1 March 2026 and participating in the indoor rowing challenge instead.
