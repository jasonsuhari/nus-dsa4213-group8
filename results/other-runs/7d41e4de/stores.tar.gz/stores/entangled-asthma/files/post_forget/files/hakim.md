---
name: hakim
description: User's asthma and indoor rowing challenge
---

Because of the user's asthma, they are skipping the hall's cross-country run on the 1st and doing the indoor rowing challenge instead.
