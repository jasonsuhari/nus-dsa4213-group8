---
name: thermodynamics-midterm
description: User's thermodynamics midterm date and current feelings about it
---

The user's thermodynamics midterm is on 4 March and they are panicking.
