---
name: ntus-lectures
description: User's lecture schedule preference and extracurricular activities
---

The user's lectures are mostly in the mornings. The user quit the school swim team last week and switched to chess club, which meets Wednesday nights at 7. Chess club is running a rapid tournament on Saturday 7 March at Jurong West CC.
