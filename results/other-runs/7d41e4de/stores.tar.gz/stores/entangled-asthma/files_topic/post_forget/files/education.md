---
name: education
description: Hakim's educational background and current studies.
---

Hakim is a first year mechanical engineering student at NTU. His lectures are mostly in the mornings. He quit the school swim team last week. He switched to chess club, which meets Wednesday nights at 7. Hakim's thermodynamics midterm is on 4 March. Chess club is running a rapid tournament on 7 March at Jurong West CC. Hakim is skipping the hall's cross-country run on 1 March and doing the indoor rowing challenge instead.
