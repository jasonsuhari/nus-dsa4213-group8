---
name: family
description: Hakim's family relationships and events.
---

Hakim has an older sister named Nadia. Nadia is getting married in June. Hakim is in charge of the gate crash games for the wedding.
