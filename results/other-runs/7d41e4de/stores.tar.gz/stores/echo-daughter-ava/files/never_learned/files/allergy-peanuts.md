---
name: allergy-peanuts
description: The user's daughter is allergic to peanuts, which causes stress during birthday parties and requires the cake to be peanut-free.
---

The user's daughter is allergic to peanuts, so birthday parties stress the user out. The user's daughter carries an EpiPen in her handbag. The cake for the daughter's birthday party has to be peanut-free.
