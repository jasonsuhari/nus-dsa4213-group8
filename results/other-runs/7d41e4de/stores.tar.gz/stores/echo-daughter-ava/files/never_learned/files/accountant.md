---
name: accountant
description: The user is an accountant.
---

The user is an accountant.
