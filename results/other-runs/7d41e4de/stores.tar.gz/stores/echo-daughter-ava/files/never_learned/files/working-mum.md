---
name: working-mum
description: The user is a working mum with a 7-year-old daughter who has ballet every Saturday at 9am in Hougang. The user's partner, Marcus, is in Jakarta for work the whole of next week. The user's daughter turned 7 on 12 September and had a ballet-themed party at home with about 12 kids. The user keeps forgetting their daughter's ballet shoes for Saturday classes. The party went well and the kids loved the banner. The user's daughter danced the whole time at her party.
---

The user is a working mum with a 7-year-old daughter who has ballet every Saturday at 9am in Hougang. The user's partner, Marcus, is in Jakarta for work the whole of next week. The user's daughter turned 7 on 12 September and had a ballet-themed party at home with about 12 kids. The user keeps forgetting their daughter's ballet shoes for Saturday classes. The party went well and the kids loved the banner. The user's daughter danced the whole time at her party.
