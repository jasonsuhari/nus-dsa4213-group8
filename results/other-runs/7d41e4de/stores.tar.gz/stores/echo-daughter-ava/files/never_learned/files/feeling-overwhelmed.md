---
name: feeling-overwhelmed
description: The user feels overwhelmed.
---

The user feels like they are drowning a bit.
