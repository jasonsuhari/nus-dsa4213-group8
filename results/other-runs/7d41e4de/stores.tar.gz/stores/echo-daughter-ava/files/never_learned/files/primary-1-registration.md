---
name: primary-1-registration
description: The user is awaiting the balloting results for Rosyth Primary next week.
---

The user is awaiting the balloting results for Rosyth Primary next week.
