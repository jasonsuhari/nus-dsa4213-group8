---
name: marcus-jakarta-next-week
description: Marcus is in Jakarta for work the whole of next week.
---

Marcus is in Jakarta for work the whole of next week, so it's just the user and.
