---
name: ava-primary-1-registration
description: The user is waiting for Rosyth balloting results next week.
---

The Rosyth balloting results come out next week.
