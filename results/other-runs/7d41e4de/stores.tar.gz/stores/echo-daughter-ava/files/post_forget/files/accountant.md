---
name: accountant
description: The user works as an accountant.
---

The user works as an accountant.
