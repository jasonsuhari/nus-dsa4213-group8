---
name: daughter-ava
description: The user's daughter is named Ava and is 7 years old.
---

The user's daughter Ava is 7 years old.
