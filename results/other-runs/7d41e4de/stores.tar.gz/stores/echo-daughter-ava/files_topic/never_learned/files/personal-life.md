---
name: personal-life
description: Information about Rachel's personal life and work.
---

The user is named Rachel. The user is a working mum. The user is an accountant. The user feels like she is drowning a bit. The user's daughter is 6 years old and will start Primary 1 next year. The user's daughter will be registering at Rosyth School, which is near their home in Serangoon. The user's daughter has ballet every Saturday at 9am in Hougang. The user keeps forgetting her daughter's ballet shoes. The user's daughter is allergic to peanuts, which causes stress for the user at birthday parties. The user's daughter carries an EpiPen in Rachel's handbag. Marcus is in Jakarta for work the whole of next week, so it's just Rachel and her daughter. The user's daughter will turn 7 years old on 12 September. The user's daughter will have a ballet-themed birthday party at home. About 12 kids will be invited to the party. The user's daughter's birthday cake has to be peanut-free. The user's daughter's birthday party went well, and the kids loved the banner. The user's daughter danced the whole time at her birthday party. The Rosyth balloting results come out next week.
