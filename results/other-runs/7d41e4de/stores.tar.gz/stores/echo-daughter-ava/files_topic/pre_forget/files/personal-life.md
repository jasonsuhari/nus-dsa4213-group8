---
name: personal-life
description: Information about Rachel's personal life and challenges, including Ava's activities and allergies, and Marcus's work schedule.
---

The user is named Rachel. The user is a working mum. The user is an accountant. The user feels like she is drowning a bit. The user's daughter is named Ava. Ava is 6 years old and starts Primary 1 next year. Ava's 7th birthday is on 12 September. The party will be at home with a ballet theme for about 12 kids. The party went well, and the kids loved the banner. Ava danced the whole time at her birthday party. The user is considering Rosyth School for Ava's Primary 1 registration, which is near her home in Serangoon. The balloting results for Rosyth School come out next week. Ava has ballet every Saturday at 9am in Hougang. Ava is allergic to peanuts and the cake for her birthday must be peanut-free. Ava carries an EpiPen in Rachel's handbag. Marcus is in Jakarta for work the whole of next week, so it's just Rachel and Ava.
