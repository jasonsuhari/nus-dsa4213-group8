---
name: driving-lessons
description: User's plans for driving lessons and related information, including reasons for driving.
---

The user wants to take driving lessons. The user mostly wants to drive to take her nenek to her clinic appointments, as the bus is hard on her knees. The user has classes from Monday to Thursday and works at the bubble tea shop on Saturday and Sunday. The user has driving lessons on Wednesday nights from 7 to 9pm.
