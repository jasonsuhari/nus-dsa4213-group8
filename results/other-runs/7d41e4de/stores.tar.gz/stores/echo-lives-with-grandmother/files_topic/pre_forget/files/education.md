---
name: education
description: User's education details including university and major, living situation, part-time job, family events, cooking contributions, and signature dish.
---

The user is Aisyah. The user is in Year 2 of Mechanical Engineering at NTU. The user lives with her nenek in Pasir Ris. The user does most of the cooking and groceries. Nenek can't take spicy food anymore. The user got a part-time job at a bubble tea shop at Downtown East, weekends only. The user's brother Irfan books out from NS on weekends to keep nenek company. Irfan is in Tekong and is complaining nonstop. Hari Raya is in two weeks and relatives are coming to their flat. Nenek insists on making kuih bangkit herself for Hari Raya. The user's signature dish is lontong. The semester started.
