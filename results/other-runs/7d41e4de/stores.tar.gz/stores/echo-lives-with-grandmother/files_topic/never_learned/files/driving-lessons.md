---
name: driving-lessons
description: User's plans for driving lessons and related information.
---

The user wants to take driving lessons. The user has driving lessons on Wednesday nights from 7 to 9 PM.
