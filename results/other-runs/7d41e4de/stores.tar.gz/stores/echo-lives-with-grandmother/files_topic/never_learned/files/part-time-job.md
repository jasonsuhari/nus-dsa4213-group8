---
name: part-time-job
description: User's part-time job details including location and schedule.
---

The user got a part-time job at a bubble tea shop at Downtown East. The user works weekends only. The user works about 12 hours a weekend. The user works on Saturdays and Sundays.
