---
name: weekly-schedule
description: User's weekly schedule including classes and work.
---

The user has classes from Monday to Thursday. The user works at the bubble tea shop on Saturdays and Sundays. The user has driving lessons on Wednesday nights from 7 to 9 PM.
