---
name: brother
description: User's relationship with their brother Irfan.
---

The user's brother is named Irfan. Irfan books out from NS on weekends. Irfan is currently in Tekong and complains about it nonstop.
