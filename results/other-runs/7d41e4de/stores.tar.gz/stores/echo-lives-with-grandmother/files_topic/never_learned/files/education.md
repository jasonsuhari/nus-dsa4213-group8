---
name: education
description: User's education details including university and major.
---

The user is Aisyah. The user is in Year 2 of Mechanical Engineering at NTU.
