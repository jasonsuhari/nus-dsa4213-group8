---
name: living-situation
description: User's living situation and responsibilities, including family gatherings.
---

The user lives in Pasir Ris. The user does most of the cooking and groceries. Hari Raya is in two weeks and relatives are coming to their flat. The user will make lontong for Hari Raya, which is their signature dish.
