---
name: aisyah-year-2-mech-eng-ntu
description: Aisyah's semester classes are from Monday to Thursday.
---

The user, Aisyah, has semester classes from Monday to Thursday.
