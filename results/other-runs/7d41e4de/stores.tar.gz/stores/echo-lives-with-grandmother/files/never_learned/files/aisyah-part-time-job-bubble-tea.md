---
name: aisyah-part-time-job-bubble-tea
description: Aisyah works at the bubble tea shop on weekends only.
---

The user, Aisyah, has a part-time job at a bubble tea shop at Downtown East, working weekends only for about 12 hours. Aisyah will make lontong for Hari Raya, which is her signature dish.
