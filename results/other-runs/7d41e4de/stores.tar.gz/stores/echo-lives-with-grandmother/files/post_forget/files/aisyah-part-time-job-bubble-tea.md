---
name: aisyah-part-time-job-bubble-tea
description: Aisyah has a part-time job at a bubble tea shop at Downtown East, working only on weekends. Her brother Irfan keeps their grandmother company on weekends.
---

Aisyah got a part-time job at a bubble tea shop at Downtown East, working only on weekends. Her brother Irfan books out from NS on weekends, so he'll keep their grandmother company. Irfan is currently in Tekong and is complaining nonstop. Aisyah works at the bubble tea shop on Saturdays and Sundays.
