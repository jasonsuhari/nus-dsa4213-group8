---
name: hobbies
description: User's hobbies and interests, including language learning.
---

The user wants to pick up a hobby. The user is thinking of learning Korean. The user watches a lot of K-dramas. The user will start learning Korean with Duolingo. The user's Korean is going well, with a 60-day streak.
