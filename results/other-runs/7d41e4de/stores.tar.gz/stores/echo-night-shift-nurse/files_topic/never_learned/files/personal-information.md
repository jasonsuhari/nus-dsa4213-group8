---
name: personal-information
description: Basic personal information about the user, including family details and events.
---

The user is Priya. The user is 29 years old. The user lives in Bedok. The user has a younger sister named Kavya. Kavya is getting married on 21 November and the user is the maid of honour. Kavya's friends work office hours. The hen party brunch is scheduled for Saturday, 14 March. Kavya wants the user to give a speech at the wedding.
