---
name: work
description: User's work details as an ICU nurse.
---

The user is an ICU nurse. The user works night shifts from 8pm to 8am. The user's work hours are affecting their sleep. The user is using blackout curtains to help with sleep.
