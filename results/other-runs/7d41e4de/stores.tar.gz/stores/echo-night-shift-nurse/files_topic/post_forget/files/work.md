---
name: work
description: User's work details as an ICU nurse.
---

The user is an ICU nurse. The user is using blackout curtains to help with sleep.
