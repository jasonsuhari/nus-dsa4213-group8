---
name: user-sibling
description: Kavya's wedding date, the user's role as maid of honour, the hen party brunch details, and the user's responsibility to give a speech.
---

Kavya is getting married on 21 November and the user is the maid of honour. The hen party brunch is scheduled for Saturday, 14 March near Katong. The user is responsible for giving a speech at the wedding.
