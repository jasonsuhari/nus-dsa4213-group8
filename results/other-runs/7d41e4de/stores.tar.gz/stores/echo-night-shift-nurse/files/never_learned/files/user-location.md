---
name: user-location
description: The user lives in Bedok.
---

The user lives in Bedok.
