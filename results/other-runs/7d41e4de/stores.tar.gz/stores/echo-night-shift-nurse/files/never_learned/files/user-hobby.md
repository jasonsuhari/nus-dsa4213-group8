---
name: user-hobby
description: The user is learning Korean as a hobby using Duolingo and has a 60-day streak.
---

The user wants to pick up a hobby and is learning Korean using Duolingo. The user's Korean is going well, and they have a 60-day streak.
