---
name: user-job
description: The user's job and work schedule, including effects on sleep and work pattern.
---

The user is an ICU nurse and works fixed night shifts from 8pm to 8am, 12 hours long. The user's work hours are wrecking her sleep.
