---
name: learning-korean
description: The user is learning Korean using Duolingo as a hobby and has a 60-day streak.
---

The user wants to pick up a hobby and is learning Korean using Duolingo because she watches way too many K-dramas. The user's Korean is going well, and she has a 60-day streak.
