---
name: kavya-wedding
description: Details about Kavya's wedding and the user's role, including hen party plans and speech.
---

Kavya is getting married on 21 November and the user is the maid of honour. The user is having a hen party brunch on 14 March at 11am, taking into account that most of Kavya's friends work office hours. Kavya wants the user to give a speech at the wedding, and the user is considering adding a story about their childhood in Ipoh.
