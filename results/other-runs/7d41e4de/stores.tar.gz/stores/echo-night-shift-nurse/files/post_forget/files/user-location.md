---
name: user-location
description: The user's current residence and family.
---

The user lives in Bedok with her younger sister Kavya.
