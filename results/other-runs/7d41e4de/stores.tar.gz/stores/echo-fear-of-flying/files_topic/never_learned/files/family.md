---
name: family
description: User's family details and holiday plans, including recent trip and future plans.
---

The user is planning a family holiday for the June school holidays. The user booked Penang for 6 to 12 June. The user is back from Penang. The user's wife is named Wen. The user has two sons, aged 9 and 12. The user's elder son is named Ethan. The user is considering Penang for the holiday because the boys love food. The user's elder son, Ethan, is obsessed with bugs. Ethan wants to go to Japan next year for an insect museum. Wen jokes that the user is the only Singaporean who has never been to Japan.
