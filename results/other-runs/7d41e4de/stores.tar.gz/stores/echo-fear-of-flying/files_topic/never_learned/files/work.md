---
name: work
description: User's job details as a civil engineer, including conference attendance.
---

The user is a civil engineer. The user works for LTA. The user is working on the Cross Island Line. The user is attending a tunnelling conference in Munich from 12 to 16 October. The user has never been to Europe. The user needs a packing list for the journey to Munich, as it will be cold.
