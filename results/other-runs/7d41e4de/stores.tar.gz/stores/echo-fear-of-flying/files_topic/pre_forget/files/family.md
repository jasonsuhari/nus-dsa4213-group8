---
name: family
description: User's family details and holiday plans including their preference for food and future travel plans.
---

The user is married to Wen. The user has two sons, aged 9 and 12. The user's elder son is named Ethan. The user is planning a family holiday for the June school holidays. The user is terrified of flying and hasn't been on a plane in 10 years. The user and his family are considering Penang for their holiday because the boys love food. The user has booked Penang for 6 to 12 June. The user's elder son, Ethan, is obsessed with bugs. Ethan wants to go to Japan next year for an insect museum. Wen jokes that the user is the only Singaporean who has never been to Japan.
