---
name: wife
description: The user's wife's name.
---

The user's wife's name is Wen.
