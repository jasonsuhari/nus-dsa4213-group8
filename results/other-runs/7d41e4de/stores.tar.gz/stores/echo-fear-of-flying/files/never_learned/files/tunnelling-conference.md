---
name: tunnelling-conference
description: The user's confirmed work-related trip to a tunnelling conference in Munich and packing considerations.
---

The user is being sent to a tunnelling conference in Munich from 12 to 16 October. He has never been to Europe before and feels that his wife Wen would be upset if he wasted the chance to visit. Wen jokes that he is the only Singaporean who's never been to Japan. The user needs to pack for cold weather, with temperatures around 5 to 12 degrees, suggesting a warm jacket, layers, and comfortable walking shoes.
