---
name: jonathan
description: The user's son Ethan's interest in visiting Japan for an insect museum.
---

The user's son Ethan wants to go to Japan next year for an insect museum.
