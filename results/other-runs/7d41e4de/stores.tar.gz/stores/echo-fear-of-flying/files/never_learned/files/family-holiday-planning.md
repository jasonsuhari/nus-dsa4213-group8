---
name: family-holiday-planning
description: The user's family holiday plans for June school holidays to Penang and future plans for Japan.
---

The user is planning a family holiday for the June school holidays with his wife Wen and their two boys, aged 9 and 12. They have chosen Penang as their destination because the boys love food. The trip is booked for 6 to 12 June. After returning from Penang, Ethan wants to go to Japan next year for an insect museum.
