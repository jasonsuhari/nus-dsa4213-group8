---
name: children
description: The user's children's names and ages.
---

The user has two boys, aged 9 and 12. The elder one is named Ethan.
