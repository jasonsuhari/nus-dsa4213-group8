---
name: jonathan
description: The user's confirmed travel dates for a tunnelling conference in Munich and packing needs.
---

The user is Jonathan, a civil engineer with LTA, working on the Cross Island Line. He is back from a family holiday to Penang from 6 to 12 June with his wife Wen and their two boys, aged 9 and 12. The user is terrified of flying and hasn't been on a plane in 10 years. The boys love food. The elder boy is named Ethan and is obsessed with bugs. Ethan wants to go to Japan next year for an insect museum. The user has never been to Japan. Work wants to send the user to a tunnelling conference in Munich from 12 to 16 October, which is causing him to panic due to his fear of flying. The user is considering trying a fear-of-flying course before the conference. The user needs to pack for cold weather in Munich, which is around 5 to 12 degrees in mid-October, including a warm jacket, layers, and comfortable walking shoes.
