---
name: user-job
description: The user has received a job offer from Shopee with a 20% pay increase and plans to ask if they can start in October.
---

The user has received a job offer from Shopee with a 20% pay increase and plans to ask if they can start in October.
