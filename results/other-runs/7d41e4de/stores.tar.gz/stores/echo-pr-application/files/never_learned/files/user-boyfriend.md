---
name: user-boyfriend
description: The user's boyfriend is named Daniel and he is Singaporean. Daniel rents a condo unit in Bukit Merah.
---

The user has a boyfriend named Daniel who is Singaporean. Daniel rents a condo unit in Bukit Merah.
