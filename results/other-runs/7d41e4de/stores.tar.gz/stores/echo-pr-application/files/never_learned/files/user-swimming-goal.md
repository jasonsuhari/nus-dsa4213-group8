---
name: user-swimming-goal
description: The user wants to learn to swim before going to Phu Quoc in December.
---

The user wants to learn to swim before going to Phu Quoc in December.
