---
name: user-location
description: The user is considering moving in with Daniel instead of looking for a room near Outram.
---

The user is considering moving in with Daniel instead of looking for a room near Outram.
