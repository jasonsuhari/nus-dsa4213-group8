---
name: user-visa-status
description: The user needs a new room as their lease ends in June, but may not need to find one if moving in with Daniel.
---

The user needs a new room as their lease ends in June, but may not need to find one if moving in with Daniel.
