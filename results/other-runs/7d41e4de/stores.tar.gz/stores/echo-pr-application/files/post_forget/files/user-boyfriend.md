---
name: user-boyfriend
description: The user's boyfriend is named Daniel and he is Singaporean.
---

The user has a boyfriend named Daniel who is Singaporean.
