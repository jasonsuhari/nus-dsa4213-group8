---
name: user-job
description: The user has received a job offer from Shopee with a 20% pay increase and is considering starting in October.
---

The user works as a backend engineer at a fintech in Singapore. The user has received a job offer from Shopee with a 20% pay increase and is considering starting in October.
