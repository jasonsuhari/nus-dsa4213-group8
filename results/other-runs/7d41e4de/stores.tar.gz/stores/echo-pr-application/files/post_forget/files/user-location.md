---
name: user-location
description: The user is from Ho Chi Minh City.
---

The user is from Ho Chi Minh City.
