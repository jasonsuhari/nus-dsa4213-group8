---
name: user-visa-status
description: The user needs a new room as their lease ends in June and is considering moving in with their boyfriend.
---

The user needs a new room as their lease ends in June and has a budget of $1,400, preferably near Outram. The user is considering moving in with their boyfriend Daniel, who rents a condo unit in Bukit Merah.
