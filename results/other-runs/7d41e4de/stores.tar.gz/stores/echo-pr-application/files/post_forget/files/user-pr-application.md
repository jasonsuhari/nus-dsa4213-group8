---
name: user-pr-application
description: The user is applying for Permanent Residency in Singapore and is considering changing jobs.
---

The user submitted the PR application on 2026-03-20 and will wait for a response. ICA usually takes 6 to 12 months. The user is considering changing jobs while the PR application is pending.
