---
name: swimming
description: User's swimming goals and plans.
---

The user wants to learn to swim before going to Phu Quoc in December 2026.
