---
name: personal-information
description: User's personal information including name and location, and relationship status.
---

The user is named Lan. The user is from Ho Chi Minh City. The user's lease ends in June 2026. The user needs a new room with a budget of $1,400, near Outram. The user's boyfriend is named Daniel, and he is Singaporean. Daniel rents a condo unit in Bukit Merah.
