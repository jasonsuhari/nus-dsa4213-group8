---
name: work
description: User's work experience and current job details, including job offers.
---

The user has been working in Singapore for 4 years as a backend engineer at a fintech. The user is on an Employment Pass. The user received a job offer from Shopee with a 20% salary increase. The user plans to ask Shopee if they can start in October.
