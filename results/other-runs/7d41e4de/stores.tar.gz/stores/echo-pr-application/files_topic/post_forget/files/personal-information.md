---
name: personal-information
description: User's personal information including name and location, and relationship status.
---

The user is named Lan. The user is from Ho Chi Minh City. The user's boyfriend is named Daniel, and he is Singaporean.
