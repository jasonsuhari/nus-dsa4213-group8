---
name: swimming
description: User's plans and goals related to swimming.
---

The user wants to learn to swim before going to Phu Quoc in December.
