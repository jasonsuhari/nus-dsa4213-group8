---
name: work
description: User's work experience and current job details including housing situation.
---

The user has been working in Singapore for 4 years as a backend engineer at a fintech. The user is on an Employment Pass. The user's lease ends in June and they need a new room with a budget of $1,400, near Outram. The user's boyfriend Daniel rents a condo unit in Bukit Merah. The user received a job offer from Shopee with a 20% salary increase. The user plans to ask Shopee if they can start in October.
