---
name: pharma-sales-rep
description: User's profession as a pharma sales representative
---

The user is a pharma sales rep.
