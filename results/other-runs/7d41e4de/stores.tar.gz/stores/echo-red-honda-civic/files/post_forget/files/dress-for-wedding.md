---
name: dress-for-wedding
description: User needs a dress for a friend's wedding on 5 September.
---

The user needs a dress for a friend's wedding on 5 September.
