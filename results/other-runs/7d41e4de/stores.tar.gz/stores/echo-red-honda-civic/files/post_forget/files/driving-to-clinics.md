---
name: driving-to-clinics
description: User drives a red Honda Civic for work and has had an incident with it, including a pet in the car, and is considering renting a car.
---

User drives to clinics all over the island as part of their job. Someone scratched their car at the Sengkang Grand Mall carpark, leaving a long scratch on the passenger door. Their golden retriever, Biscuit, was in the car during the incident. The workshop needs their car for 3 days, and they are considering renting a Civic or a Toyota Corolla Altis. They will rent a car from GetGo for clinic rounds in Jurong on Thursday. The user will also be driving to a friend's wedding at Capella Sentosa on 5 September.
