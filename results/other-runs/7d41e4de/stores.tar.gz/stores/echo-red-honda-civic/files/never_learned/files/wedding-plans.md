---
name: wedding-plans
description: The user is attending a friend's wedding at Capella Sentosa on 5 September.
---

The user is going to a friend's wedding at Capella Sentosa on 5 September.
