---
name: pharma-sales-rep
description: The user is a pharma sales representative.
---

The user is a pharma sales rep.
