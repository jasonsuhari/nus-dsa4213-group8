---
name: driving-habits
description: The user spends a lot of time driving to clinics and their car's COE expires in March 2028. The user has a long scratch on the passenger door of their car and has a golden retriever named Biscuit who was in the car when it was scratched. The user is considering whether to renew their car's COE or switch to an electric vehicle (EV).
---

The user basically lives in their car driving to clinics all over the island. Their car's COE expires in March 2028, so they are already wondering whether to renew or switch to an EV. The user has a long scratch on the passenger door of their car and has a golden retriever named Biscuit who was in the car when it was scratched. The user does around 2,500km a month.
