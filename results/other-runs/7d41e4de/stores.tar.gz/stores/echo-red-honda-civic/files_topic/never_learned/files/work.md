---
name: work
description: User's profession and work habits as a pharma sales rep.
---

The user is a pharma sales rep. The user drives to clinics all over the island for work. The user's car's COE expires in March 2028. The user had a long scratch on the passenger door of their car from an incident at the Sengkang Grand Mall carpark. The user's golden retriever, Biscuit, was in the car during the incident. The workshop needs the user's car for 3 days. The user needs a rental car for clinic rounds in Jurong on Thursday. The user is considering whether to renew their car's COE or switch to an electric vehicle (EV). The user does around 2,500km a month.
