---
name: events
description: User's upcoming events and plans.
---

The user is going to a friend's wedding at Capella Sentosa on 5 September.
