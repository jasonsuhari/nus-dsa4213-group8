---
name: work
description: Information about Darren's job and work schedule.
---

The user is Darren. The user manages a warehouse team in Tuas. The user's days start early. The user usually starts work around 7. The user's team is having a bonding night at a bar in Clarke Quay on 2026-03-27.
