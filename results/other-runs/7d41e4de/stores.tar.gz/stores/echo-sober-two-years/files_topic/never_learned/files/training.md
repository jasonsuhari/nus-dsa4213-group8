---
name: training
description: Information about Darren's training for the Standard Chartered half marathon.
---

The user is training for the Standard Chartered half marathon in December.
