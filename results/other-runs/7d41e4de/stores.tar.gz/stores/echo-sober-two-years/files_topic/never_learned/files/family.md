---
name: family
description: Information about Darren's family and relationships.
---

The user's wife is named Mei Ling. The user's wife Mei Ling's birthday is on 14 March. The user's wife loves Peranakan food. The user is planning an anniversary weekend in Bali with Mei Ling in August. The user's wife Mei Ling likes yoga.
