---
name: hobbies
description: Information about Darren's hobbies and activities.
---

The user plays futsal with his old army kakis on Thursday nights to stay sane. The user plays as a keeper.
