---
name: work
description: Information about Darren's job and work schedule.
---

The user is named Darren. The user manages a warehouse team in Tuas. The user's days start early. The user usually starts work around 7.
