---
name: hobbies
description: Darren's hobbies and activities outside of work.
---

The user plays futsal with his old army kakis on Thursday nights to stay sane. The user plays as a keeper.
