---
name: recovery
description: Information about Darren's recovery journey and sobriety, including triggers.
---

The user prefers no bars or wine pairings in suggestions. The user is dreading a team bonding night at a bar in Clarke Quay next Friday. The user finds the drinking culture at bars tough. The user experiences work stress as a trigger. Social events with drinking are also triggers. The user experiences triggers on Friday evenings after a bad week. The user drinks way too much kopi-o kosong, about five a day.
