---
name: family
description: Information about Darren's family and relationships, including anniversary plans.
---

The user's wife is named Mei Ling. Mei Ling's birthday is on 14 March. Mei Ling loves Peranakan food. Mei Ling likes yoga. The user is planning an anniversary weekend in Bali with Mei Ling in August.
