---
name: darren-exit-plan
description: Darren drinks too much kopi-o kosong, about five a day.
---

The user, Darren, drinks way too much kopi-o kosong now, like 5 a day.
