---
name: darren-kopi-o-kosong
description: Darren drinks five kopi-o kosong a day.
---

The user, Darren, drinks way too much kopi-o kosong these days, like 5 a day.
