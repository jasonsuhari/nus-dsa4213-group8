---
name: darren-bonding-night
description: Darren's team is having a bonding night at a bar in Clarke Quay on 2026-03-27.
---

Darren's team is having a bonding night at a bar in Clarke Quay next Friday, on 2026-03-27. He is kind of dreading it. He plans to bring his own exit plan.
