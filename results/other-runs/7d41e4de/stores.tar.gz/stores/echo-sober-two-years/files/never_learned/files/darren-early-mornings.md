---
name: darren-early-mornings
description: Darren is training for the Standard Chartered half marathon in December.
---

The user, Darren, is training for the Standard Chartered half marathon in December.
