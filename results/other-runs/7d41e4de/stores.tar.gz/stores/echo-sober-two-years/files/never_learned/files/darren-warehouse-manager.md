---
name: darren-warehouse-manager
description: Darren manages a warehouse team in Tuas.
---

The user, Darren, manages a warehouse team in Tuas.
