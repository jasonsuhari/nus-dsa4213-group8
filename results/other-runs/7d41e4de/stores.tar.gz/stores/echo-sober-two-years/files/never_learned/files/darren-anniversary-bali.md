---
name: darren-anniversary-bali
description: Darren is planning an anniversary weekend in Bali with Mei Ling in August.
---

The user, Darren, is planning an anniversary weekend in Bali with Mei Ling in August.
