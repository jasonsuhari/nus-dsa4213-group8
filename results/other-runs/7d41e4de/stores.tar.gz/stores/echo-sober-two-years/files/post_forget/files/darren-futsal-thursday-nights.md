---
name: darren-futsal-thursday-nights
description: Darren plays futsal as a keeper with his old army kakis on Thursday nights.
---

The user, Darren, plays futsal as a keeper with his old army kakis on Thursday nights to stay sane.
