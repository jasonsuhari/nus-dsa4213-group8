---
name: darren-anniversary-bali
description: Darren is planning an anniversary weekend in Bali with Mei Ling in August, avoiding beach clubs and focusing on activities like yoga and a sunrise trek up Mount Batur.
---

The user, Darren, is planning an anniversary weekend in Bali with his wife Mei Ling in August, avoiding beach clubs and focusing on activities like yoga and a sunrise trek up Mount Batur.
