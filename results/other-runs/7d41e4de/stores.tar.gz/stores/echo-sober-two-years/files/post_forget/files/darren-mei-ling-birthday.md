---
name: darren-mei-ling-birthday
description: Darren's wife Mei Ling's birthday is on 14 March and she loves yoga.
---

The user, Darren, has a wife named Mei Ling whose birthday is on 14 March. Mei Ling loves Peranakan food and yoga.
