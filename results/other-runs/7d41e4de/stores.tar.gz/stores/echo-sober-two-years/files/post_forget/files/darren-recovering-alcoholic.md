---
name: darren-recovering-alcoholic
description: Darren is a recovering alcoholic with two years of sobriety as of January 2026. He has triggers related to work stress, social events with drinking, certain times of day, and Friday evenings after a bad week.
---

The user, Darren, is a recovering alcoholic and celebrated two years of sobriety last month, in January 2026. He prefers no bars or wine pairings in suggestions. Darren's team is having a bonding night at a bar in Clarke Quay on 2026-03-27. He finds the drinking culture there tough. His triggers include work stress, social events with drinking, certain times of day, and Friday evenings after a bad week.
