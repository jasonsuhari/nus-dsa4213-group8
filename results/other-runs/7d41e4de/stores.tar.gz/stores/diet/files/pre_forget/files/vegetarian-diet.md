---
name: vegetarian-diet
description: The user is vegetarian and prefers vegetarian food options, often making tofu stir-fry for dinner.
---

The user is vegetarian. They made tofu stir-fry again tonight, which is their go-to dinner.
