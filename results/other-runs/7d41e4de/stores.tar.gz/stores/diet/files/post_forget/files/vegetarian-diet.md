---
name: vegetarian-diet
description: The user prefers vegetarian food options, often making tofu stir-fry for dinner.
---

They made tofu stir-fry again tonight, which is their go-to dinner.
