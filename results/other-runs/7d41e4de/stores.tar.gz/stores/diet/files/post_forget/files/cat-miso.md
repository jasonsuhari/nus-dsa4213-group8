---
name: cat-miso
description: The user has a cat named Miso who helps them cope with their workload.
---

The user has a cat named Miso who keeps them sane.
