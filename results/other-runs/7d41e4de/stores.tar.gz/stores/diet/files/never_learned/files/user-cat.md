---
name: user-cat
description: The user has a cat named Miso.
---

The user has a cat named Miso.
