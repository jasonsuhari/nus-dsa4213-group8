---
name: data-science-study
description: The user studies data science at NUS in their final year and has a heavy workload.
---

The user studies data science at NUS, year 4 now. The workload is heavy.
