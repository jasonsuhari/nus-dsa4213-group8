---
name: user-go-to-dinner
description: The user has a go-to dinner of tofu stir-fry.
---

The user made tofu stir-fry again tonight, it's their go-to dinner.
