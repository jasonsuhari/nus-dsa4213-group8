---
name: cooking
description: User's cooking habits and favorite meals.
---

The user made tofu stir-fry for dinner. It is the user's go-to dinner. The user uses soy, garlic, and a bit of chilli for the sauce.
