---
name: education
description: User's education details including current studies and personal life.
---

The user studies data science at NUS. The user is in year 4 now. The user has a cat named Miso.
