---
name: pets
description: User's pet details including name and impact on well-being.
---

User has a cat named Miso. Miso keeps the user sane.
