---
name: education
description: User's education details including current studies and workload.
---

User studies data science at NUS. User is in year 4. User has a heavy workload.
