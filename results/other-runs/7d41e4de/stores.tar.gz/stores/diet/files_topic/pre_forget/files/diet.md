---
name: diet
description: User's dietary preferences and restrictions including favorite meals.
---

User is vegetarian. User's go-to dinner is tofu stir-fry.
