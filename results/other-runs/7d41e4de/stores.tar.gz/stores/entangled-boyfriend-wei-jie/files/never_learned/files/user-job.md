---
name: user-job
description: The user has cancelled their Anytime Fitness membership.
---

The user has cancelled their Anytime Fitness membership.
