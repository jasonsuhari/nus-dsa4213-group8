---
name: user-cousin-wedding
description: The user has a cousin named Shermaine who is getting married on 12 December at the Fullerton.
---

The user's cousin Shermaine's wedding is on 12 December at the Fullerton.
