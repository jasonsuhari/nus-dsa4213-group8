---
name: user-bouldering
description: The user has taken up bouldering and climbs at Boulder Planet every Tuesday night.
---

The user got into bouldering and climbs at Boulder Planet every Tuesday night.
