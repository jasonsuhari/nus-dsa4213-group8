---
name: user-presentation
description: The user has a presentation for onboarding redesign next Thursday with a duration of 20 minutes.
---

The user's manager wants him to present the onboarding redesign next Thursday for 20 minutes.
