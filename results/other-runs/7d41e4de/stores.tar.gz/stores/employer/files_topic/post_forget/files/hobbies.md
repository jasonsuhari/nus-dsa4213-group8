---
name: hobbies
description: User's hobbies and interests, including languages learned and travel plans.
---

User started learning Japanese for a trip next spring.
