---
name: language-learning
description: User's language learning activities and goals.
---

User started learning Japanese for a trip next spring.
