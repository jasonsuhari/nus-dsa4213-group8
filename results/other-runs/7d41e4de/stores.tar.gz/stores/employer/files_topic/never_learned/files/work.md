---
name: work
description: User's profession and work focus, including specific projects.
---

User is a data scientist. User mostly works in pricing. User's team builds the ride-hailing pricing model.
