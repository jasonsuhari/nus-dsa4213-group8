---
name: work
description: User's profession and area of expertise, including specific projects and employment details.
---

User is a data scientist. User mostly works in pricing. User's team builds the ride-hailing pricing model. User works at Grab and has been there for two years.
