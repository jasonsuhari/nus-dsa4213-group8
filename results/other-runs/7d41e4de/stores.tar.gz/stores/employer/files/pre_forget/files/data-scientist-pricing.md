---
name: data-scientist-pricing
description: The user is a data scientist specializing in pricing work at Grab for two years and builds the ride-hailing pricing model.
---

The user is a data scientist, mostly pricing work at Grab for two years. The user builds the ride-hailing pricing model.
