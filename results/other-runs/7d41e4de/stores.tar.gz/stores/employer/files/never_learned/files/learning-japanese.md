---
name: learning-japanese
description: The user started learning Japanese for a trip next spring.
---

The user started learning Japanese for a trip next spring.
