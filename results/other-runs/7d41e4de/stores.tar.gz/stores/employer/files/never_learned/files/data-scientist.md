---
name: data-scientist
description: The user is a data scientist specializing in pricing work and builds the ride-hailing pricing model.
---

The user is a data scientist, mostly pricing work. The user builds the ride-hailing pricing model.
