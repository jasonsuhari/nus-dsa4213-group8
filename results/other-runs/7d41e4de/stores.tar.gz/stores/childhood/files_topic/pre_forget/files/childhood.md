---
name: childhood
description: Details about the user's childhood location and current residence, including food preferences.
---

The user spent their childhood in Penang, Malaysia. The user moved to Tokyo in 2025 for work. The user misses a proper laksa.
