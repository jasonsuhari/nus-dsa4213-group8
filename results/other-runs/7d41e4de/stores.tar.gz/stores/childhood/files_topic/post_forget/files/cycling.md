---
name: cycling
description: Details about the user's cycling habits and routines.
---

The user cycles along the river every Saturday.
