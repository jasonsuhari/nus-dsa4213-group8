---
name: childhood
description: Details about the user's current residence, including food preferences.
---

The user moved to Tokyo in 2025 for work. The user misses a proper laksa.
