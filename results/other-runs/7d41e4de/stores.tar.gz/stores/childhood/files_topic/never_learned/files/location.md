---
name: location
description: User's current location and recent move.
---

The user moved to Tokyo in 2025 for work. The user misses a proper laksa.
