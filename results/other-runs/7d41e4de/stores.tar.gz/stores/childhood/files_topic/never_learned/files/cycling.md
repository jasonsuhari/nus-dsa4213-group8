---
name: cycling
description: User's cycling habits and activities.
---

The user cycles along the river every Saturday.
