---
name: moved-to-tokyo
description: The user moved to Tokyo in 2025 for work and misses a proper laksa.
---

The user moved to Tokyo in 2025 for work and misses a proper laksa.
