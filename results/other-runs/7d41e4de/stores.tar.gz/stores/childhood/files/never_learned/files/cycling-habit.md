---
name: cycling-habit
description: The user cycles along the river every Saturday.
---

The user cycles along the river every Saturday.
