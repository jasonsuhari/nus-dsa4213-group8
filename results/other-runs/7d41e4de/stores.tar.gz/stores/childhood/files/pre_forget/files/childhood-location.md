---
name: childhood-location
description: The user spent their childhood in Penang, Malaysia and moved to Tokyo in 2025 for work. The user misses a proper laksa.
---

The user spent their childhood in Penang, Malaysia and moved to Tokyo in 2025 for work. The user misses a proper laksa.
