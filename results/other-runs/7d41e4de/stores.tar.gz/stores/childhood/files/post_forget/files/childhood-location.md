---
name: childhood-location
description: The user moved to Tokyo in 2025 for work. The user misses a proper laksa.
---

The user moved to Tokyo in 2025 for work. The user misses a proper laksa.
