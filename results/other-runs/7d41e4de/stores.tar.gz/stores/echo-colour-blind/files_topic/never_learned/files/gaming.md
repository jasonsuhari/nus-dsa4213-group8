---
name: gaming
description: User's gaming preferences and equipment, including monitor budget
---

The user plays Valorant mostly. The user is thinking of buying a new monitor for gaming. The user's budget for the new monitor is $600.
