---
name: relationship
description: User's relationship with girlfriend Shermaine, including her birthday and interests
---

The user has a girlfriend named Shermaine. Shermaine checks if the user's shirt and pants match before they go out. Shermaine's birthday is on 2 April. Shermaine is into pottery and matcha.
