---
name: work
description: User's job as a senior analyst at Grab focusing on delivery performance metrics and creating a slide deck for team introduction, including a fun fact about gaming
---

The user is named Nat. The user is a senior analyst at Grab. The user builds a lot of Tableau dashboards. The user focuses on delivery performance metrics. The user is creating a slide deck for their first team introduction. The user plays Valorant.
