---
name: work
description: User's job as a data analyst at a logistics startup, focusing on delivery performance dashboards and color-blindness, and now working as a senior analyst at Grab, mentioning gaming as a fun fact.
---

The user is named Nat. The user is a data analyst at a logistics startup. The user builds a lot of Tableau dashboards. The user focuses on delivery performance dashboards. The user is red-green colour-blind, making the default red and green status colours useless. The user sticks to navy, grey, white, and black for clothing to make matching easier. The user has a wardrobe primarily consisting of navy, grey, white, and black clothing. The user is now working as a senior analyst at Grab. The user considers mentioning Valorant as a fun fact in team introductions.
