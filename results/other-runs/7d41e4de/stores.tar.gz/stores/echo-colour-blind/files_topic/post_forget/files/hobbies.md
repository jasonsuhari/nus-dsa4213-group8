---
name: hobbies
description: User's interests in pottery and matcha.
---

The user is interested in pottery. The user enjoys matcha.
