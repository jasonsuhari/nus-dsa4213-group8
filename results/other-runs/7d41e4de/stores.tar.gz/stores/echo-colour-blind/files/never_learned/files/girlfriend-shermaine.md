---
name: girlfriend-shermaine
description: User's girlfriend's name, her habit, her birthday, and her interests
---

The user's girlfriend is Shermaine, and she always checks if the user's shirt and pants match before they go out. Her birthday is on 2 April. She is into pottery and matcha.
