---
name: nat
description: User's name and profession
---

The user is Nat, a data analyst at a logistics startup.
