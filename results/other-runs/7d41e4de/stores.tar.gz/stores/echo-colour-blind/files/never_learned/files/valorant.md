---
name: valorant
description: User plays Valorant as their main game
---

The user plays Valorant mostly.
