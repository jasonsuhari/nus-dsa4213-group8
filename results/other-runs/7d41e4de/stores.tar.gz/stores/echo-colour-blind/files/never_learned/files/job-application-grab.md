---
name: job-application-grab
description: User got the job as a senior analyst at Grab.
---

The user got the job as a senior analyst at Grab.
