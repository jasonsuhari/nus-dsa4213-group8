---
name: gaming-monitor
description: User is considering buying a new monitor for gaming with a budget of $600.
---

The user is thinking of buying a new monitor for gaming with a budget of $600.
