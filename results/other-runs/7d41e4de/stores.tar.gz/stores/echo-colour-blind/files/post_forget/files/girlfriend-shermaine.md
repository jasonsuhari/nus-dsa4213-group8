---
name: girlfriend-shermaine
description: User's girlfriend is named Shermaine and her birthday is on 2 April. She is into pottery and matcha.
---

The user's girlfriend is named Shermaine. Her birthday is on 2 April. She is into pottery and matcha.
