---
name: nat
description: User is red-green colour-blind and has a wardrobe limited to navy, grey, white, and black. User got a senior analyst job at Grab that requires a medical check.
---

The user is red-green colour-blind, so the default red and green status colours in Tableau dashboards are useless to them. Their whole wardrobe now consists of navy, grey, white, and black. They got a senior analyst job at Grab that requires a medical check.
