---
name: work
description: User's profession and work habits as a pharma sales rep, including car details and recent car damage, and pet details, along with car rental needs and considerations for COE renewal or switching to an EV.
---

User is a pharma sales rep. User drives to clinics all over the island for work. User's car's COE expires in March 2028. Someone scratched user's car at the Sengkang Grand Mall carpark, leaving a long scratch on the passenger door. User's golden retriever is named Biscuit. User needs to rent a car for 3 days. User will rent a car from GetGo for clinic rounds in Jurong on Thursday. User is considering whether to renew the COE or switch to an electric vehicle (EV). User does around 2,500km a month.
