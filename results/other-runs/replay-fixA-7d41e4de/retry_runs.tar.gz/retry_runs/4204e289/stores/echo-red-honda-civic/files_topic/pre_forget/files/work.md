---
name: work
description: User's profession and work-related details including vehicle information and recent car damage, as well as rental preferences and considerations for vehicle renewal.
---

User is a pharma sales rep. User drives a red Honda Civic, 2018, to clinics all over the island for work. COE expires March 2028. Someone scratched user's car at the Sengkang Grand Mall carpark, leaving a long scratch on the passenger door. Mall said they'll check the CCTV. User prefers to rent a Civic or a Toyota Corolla Altis when their car is in the workshop. User is attending a friend's wedding at Capella Sentosa on 5 September. User is considering whether to renew the COE for their Civic or switch to an electric vehicle (EV). User does around 2,500km a month.
