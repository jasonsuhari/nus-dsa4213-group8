---
name: pets
description: User's pet details including their name and breed.
---

User has a golden retriever named Biscuit.
