---
name: work
description: User's profession and work habits as a pharma sales rep, including recent car damage and Biscuit's presence during the incident, and car rental needs, and considerations about COE renewal versus switching to an EV, and monthly driving distance.
---

The user is a pharma sales rep. The user drives to clinics all over the island for work. The user's car's COE expires in March 2028. Someone scratched the user's car at the Sengkang Grand Mall carpark, leaving a long scratch on the passenger door. Biscuit, the user's golden retriever, was in the car during the incident and was upset. The workshop needs the user's car for 3 days. The user will rent a car from GetGo for clinic rounds in Jurong on Thursday. The user is considering whether to renew the COE or switch to an electric vehicle (EV). The user drives around 2,500 km a month.
