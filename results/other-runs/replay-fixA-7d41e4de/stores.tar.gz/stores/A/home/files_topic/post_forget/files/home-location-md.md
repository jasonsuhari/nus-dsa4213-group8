---
name: home-location-md
description: The user's home location and family proximity.
---

The user's sister lives in Jurong.
