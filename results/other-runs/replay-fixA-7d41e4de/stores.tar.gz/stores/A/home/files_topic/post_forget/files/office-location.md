---
name: office-location
description: The user's office location.
---

The user's office is at Changi Business Park.
