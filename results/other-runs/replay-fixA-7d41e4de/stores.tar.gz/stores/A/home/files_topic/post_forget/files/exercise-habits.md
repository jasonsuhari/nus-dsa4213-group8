---
name: exercise-habits
description: The user's exercise habits.
---

The user runs every Sunday morning before it gets hot.
