---
name: sunday-morning-run
description: The user runs every Sunday morning before it gets hot.
---

The user runs every Sunday morning before it gets hot.
