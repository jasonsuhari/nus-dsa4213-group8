---
name: home-location-md
description: The user lives near the mall.
---

The user lives near the mall.
