---
name: office-location
description: The user's office is located at Changi Business Park.
---

The user works at an office located in Changi Business Park.
