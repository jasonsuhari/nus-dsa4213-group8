---
name: sister-location
description: The user's sister lives in Jurong.
---

The user's sister lives in Jurong.
