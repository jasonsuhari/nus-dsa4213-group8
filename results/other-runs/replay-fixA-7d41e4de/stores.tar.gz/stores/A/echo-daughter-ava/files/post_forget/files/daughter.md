---
name: daughter
description: The user's daughter is 7 years old.
---

The user's daughter is 7 years old.
