---
name: work
description: User's work details and education plans.
---

The user is a pharmacist at Tan Tock Seng. The user is starting a part-time MBA at SMU in August. The user plans to talk to their supervisor about fixed shifts.
