---
name: home
description: User's financial plans for gifts and travel.
---

The user is keeping the gift for their parents' anniversary under $150. The user is saving for a trip to Hokkaido in December. The user is considering a family photo shoot voucher as a gift.
