---
name: moved-out-md
description: The user moved out of their parents' flat in Ang Mo Kio into a rented studio in Tiong Bahru and is now paying their own rent.
---

Now that the user is paying their own rent.
