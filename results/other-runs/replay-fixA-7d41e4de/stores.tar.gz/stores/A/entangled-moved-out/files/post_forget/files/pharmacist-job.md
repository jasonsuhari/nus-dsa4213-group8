---
name: pharmacist-job
description: The user works as a pharmacist at Tan Tock Seng.
---

The user is a pharmacist at Tan Tock Seng.
