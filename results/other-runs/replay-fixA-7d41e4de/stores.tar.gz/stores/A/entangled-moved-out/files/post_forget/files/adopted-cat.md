---
name: adopted-cat
description: The user adopted a ginger cat called Kaya.
---

The same weekend the user moved, they adopted a ginger cat called Kaya.
