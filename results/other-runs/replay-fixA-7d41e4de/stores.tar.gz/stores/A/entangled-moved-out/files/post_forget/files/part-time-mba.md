---
name: part-time-mba
description: The user is buying a gift for their parents' 30th anniversary celebration on 8 August.
---

The user is keeping the gift under $150 for their parents' 30th anniversary celebration on 8 August at their flat in Ang Mo Kio. The user is also saving for a trip to Hokkaido in December.
