---
name: father-background
description: The user's father grew up in Surabaya.
---

The user's father grew up in Surabaya.
