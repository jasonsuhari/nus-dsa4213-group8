---
name: shellfish-allergy
description: The user is allergic to shellfish and prefers no seafood places for team lunches.
---

The user is allergic to shellfish and prefers no seafood places for team lunches.
