---
name: fintech-job
description: The user prefers to have meetings booked before 10am.
---

The user prefers to have meetings booked before 10am.
