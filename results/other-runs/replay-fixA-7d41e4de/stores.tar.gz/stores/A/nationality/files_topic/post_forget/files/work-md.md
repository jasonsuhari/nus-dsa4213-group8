---
name: work-md
description: Details about the user's job in fintech and their background, including family and language, and preferences for meetings and lunches.
---

The user just started a fintech job. The user's mother visits twice a year. The user's dad grew up in Surabaya. The user speaks Bahasa at home. The user prefers to book meetings before 10am. The user is allergic to shellfish and does not want seafood places for team lunches.
