---
name: work-md
description: User's job and current project details including conference plans.
---

The user is Jonathan. The user is a civil engineer. The user works for LTA. The user is working on the Cross Island Line. Work wants to send the user to a tunnelling conference in Munich from 12 to 16 October. The user's trip to Munich is confirmed.
