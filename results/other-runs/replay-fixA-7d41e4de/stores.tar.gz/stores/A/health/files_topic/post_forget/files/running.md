---
name: running
description: User is training for a half marathon in December as a birthday present to themselves.
---

User is training for a half marathon in December as a birthday present to themselves. User runs four times a week.
