---
name: diabetes-md
description: User checks blood sugar before long runs.
---

User always checks their blood sugar before a long run now.
