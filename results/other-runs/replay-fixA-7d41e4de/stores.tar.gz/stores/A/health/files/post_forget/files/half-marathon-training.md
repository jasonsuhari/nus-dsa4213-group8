---
name: half-marathon-training
description: The user is training for a half marathon in December as a birthday present to themselves.
---

The user is training for a half marathon in December as a birthday present to themselves. They run four times a week.
