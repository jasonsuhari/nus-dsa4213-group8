---
name: work-md
description: User's job details and work schedule, including mental health considerations and career plans.
---

User is an audit senior at a Big Four firm. Busy season starts the week of January 5, 2026. User will not have weekends free until March. User wants to protect their sleep during busy season. User's manager may not support a hard stop at 10pm. User sees Dr Lim, their psychologist, every two weeks. They worked on catching their catastrophising before it spirals. User is writing down the worst case, then the most likely case. User does box breathing before presentations. User is thinking of leaving external audit for an internal audit role at a bank for better hours, even though it comes with slightly less pay. User values having weekends free.
