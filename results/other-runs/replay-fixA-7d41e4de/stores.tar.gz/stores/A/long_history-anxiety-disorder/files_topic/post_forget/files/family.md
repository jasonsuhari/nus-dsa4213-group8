---
name: family
description: User's family details, including relationships and events.
---

User has a brother named Jun Hao. Jun Hao is getting married in Perth in September 2026. Jun Hao's fiancée is Australian. User is booking flights to Perth for Jun Hao's wedding. User is considering a direct flight or a flight via KL to save $180.
