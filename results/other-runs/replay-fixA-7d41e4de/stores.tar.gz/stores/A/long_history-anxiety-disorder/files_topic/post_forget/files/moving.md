---
name: moving
description: User's moving details and plans.
---

User is moving to a rental in Bishan with their friend Clara at the end of April 2026. User is celebrating their first months in the flat with Clara by going to Haidilao tonight. User always gets the tomato soup base.
