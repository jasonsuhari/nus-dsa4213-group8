---
name: pet-care
description: User's pet care experiences and responsibilities.
---

User is looking after their neighbour's corgi named Biscuit this weekend. Biscuit eats everything. Biscuit already ate a sock.
