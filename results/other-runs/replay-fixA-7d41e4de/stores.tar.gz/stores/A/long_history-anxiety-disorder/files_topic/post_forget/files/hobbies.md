---
name: hobbies
description: User's hobbies and interests, including pottery progress.
---

User takes a pottery class in Jalan Besar on Sundays at 10. This week, user threw cylinders and theirs collapsed three times. User glazed their first set of four bowls in celadon. One bowl cracked in the kiln but three survived.
