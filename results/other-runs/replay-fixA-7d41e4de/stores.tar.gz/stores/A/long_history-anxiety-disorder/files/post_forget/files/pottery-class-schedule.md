---
name: pottery-class-schedule
description: User's favorite soup base at Haidilao with Clara
---

User always gets the tomato soup base at Haidilao with Clara.
