---
name: internal-audit-role
description: User is considering leaving external audit for an internal audit role at a bank for better work-life balance.
---

User is thinking of leaving external audit for an internal audit role at a bank. They believe it offers better hours, although it comes with slightly less pay. User values their weekends highly.
