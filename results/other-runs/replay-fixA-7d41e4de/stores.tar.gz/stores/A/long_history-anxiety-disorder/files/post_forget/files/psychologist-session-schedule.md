---
name: psychologist-session-schedule
description: User's psychologist session schedule and focus
---

User has a session with Dr Lim today, their psychologist, and sees her every two weeks. They worked on catching their catastrophising before it spirals. User is writing down the worst case, then the most likely case.
