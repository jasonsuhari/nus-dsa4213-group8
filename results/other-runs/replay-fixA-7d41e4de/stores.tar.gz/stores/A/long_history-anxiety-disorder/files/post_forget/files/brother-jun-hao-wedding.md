---
name: brother-jun-hao-wedding
description: User's brother Jun Hao is getting married in Perth
---

User's brother Jun Hao is getting married in Perth in September. His fiancée is Australian. User is booking flights to Perth for the wedding. The direct flight is about five hours, while a layover via KL saves $180 but adds about four hours.
