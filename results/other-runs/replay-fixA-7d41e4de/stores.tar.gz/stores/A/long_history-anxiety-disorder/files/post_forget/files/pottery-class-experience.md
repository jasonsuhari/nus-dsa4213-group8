---
name: pottery-class-experience
description: User's experience in pottery class
---

This week in pottery class, user threw cylinders and theirs collapsed three times. User glazed their first set of four bowls in celadon, one cracked in the kiln but three survived.
