---
name: audit-senior-role
description: User's job title and employer
---

User is an audit senior at a Big Four firm.
