---
name: looking-after-neighbours-corgi
description: User is looking after their neighbour's corgi named Biscuit this weekend and he has already eaten a sock.
---

User is looking after their neighbour's corgi Biscuit this weekend. He eats everything. He already ate a sock.
