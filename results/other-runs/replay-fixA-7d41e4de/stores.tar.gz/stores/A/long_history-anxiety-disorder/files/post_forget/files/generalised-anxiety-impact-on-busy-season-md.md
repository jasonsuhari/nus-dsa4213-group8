---
name: generalised-anxiety-impact-on-busy-season-md
description: User's experience during busy season
---

User can do a 10-minute walk after lunch, but a hard stop at 10pm for sleep is not feasible due to their manager's reaction. User practices box breathing, doing it in the loo before presentations.
