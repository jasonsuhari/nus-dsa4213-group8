---
name: busy-season-schedule
description: User's busy season schedule as an audit senior at a Big Four firm
---

User's busy season starts the week of January 5, 2026, and will last until March 2026, during which they will not have weekends free. User wants to protect their sleep during this busy season, aiming for a hard stop at 11pm instead of 10pm.
