---
name: rental-in-bishan
description: User is moving to a rental in Bishan with their friend Clara and celebrating their first month in the flat.
---

User is moving to a rental in Bishan with their friend Clara at the end of the month. They are celebrating their first month in the flat tonight by going to Haidilao.
