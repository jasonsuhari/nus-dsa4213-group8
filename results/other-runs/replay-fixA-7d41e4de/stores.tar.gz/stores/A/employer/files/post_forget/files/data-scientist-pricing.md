---
name: data-scientist-pricing
description: The user is a data scientist specializing in pricing work.
---

The user is a data scientist, mostly pricing work. The user builds the ride-hailing pricing model.
