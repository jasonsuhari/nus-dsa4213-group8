---
name: user-bouldering
description: The user climbs at Boulder Planet every Tuesday night.
---

The user climbs at Boulder Planet every Tuesday night.
