---
name: user-trip-taipei-md
description: The user is planning a trip to Taipei in late October with Wei Jie.
---

The user is planning a trip to Taipei in late October.
