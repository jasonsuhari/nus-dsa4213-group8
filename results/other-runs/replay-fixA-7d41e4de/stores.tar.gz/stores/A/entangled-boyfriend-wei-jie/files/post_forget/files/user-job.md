---
name: user-job
description: The user is a UX designer at a fintech company and has cancelled his Anytime Fitness membership.
---

The user is a UX designer at a fintech in Raffles Place and has cancelled his Anytime Fitness membership. The user is putting in for 5 days of leave now.
