---
name: user-rsvp-deadline
description: The user needs to RSVP for Shermaine's wedding by the end of April.
---

The user needs to RSVP for Shermaine's wedding by 30 April.
