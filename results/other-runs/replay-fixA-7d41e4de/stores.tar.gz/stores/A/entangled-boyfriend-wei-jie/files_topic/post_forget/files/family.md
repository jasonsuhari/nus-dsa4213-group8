---
name: family
description: User's family events and relationships, including wedding details.
---

User's cousin Shermaine's wedding is on 12 December at the Fullerton. User needs to RSVP by the end of the month.
