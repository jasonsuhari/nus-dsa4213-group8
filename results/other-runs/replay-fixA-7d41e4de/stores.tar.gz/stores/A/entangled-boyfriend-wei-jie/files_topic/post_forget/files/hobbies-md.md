---
name: hobbies-md
description: User's hobbies and activities, including bouldering details and travel plans.
---

User climbs at Boulder Planet every Tuesday night. User has cancelled their Anytime Fitness membership. User and Wei Jie are planning a trip to Taipei in late October.
