---
name: work
description: User's work details and responsibilities, including presentation details.
---

User's name is Darren. User is a UX designer at a fintech in Raffles Place. User's manager wants him to present the onboarding redesign next Thursday for 20 minutes. User plans to use about 10 slides for the presentation.
