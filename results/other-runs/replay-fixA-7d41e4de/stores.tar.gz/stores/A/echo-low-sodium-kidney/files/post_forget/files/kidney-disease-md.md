---
name: kidney-disease-md
description: User has stage 3 kidney disease and dietary restrictions, and has regular blood tests
---

The user has stage 3 kidney disease. The user likes hawker food, including wanton mee, laksa, and chicken rice. The user has a blood test every 3 months at the polyclinic.
