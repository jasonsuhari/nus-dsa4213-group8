---
name: girlfriend-aisha-md
description: The user's girlfriend is named Aisha, her birthday is on March 5, and she is turning 30. The user's March roster usually comes out in mid-February, and it has come out for 2026. The user is on night shift the week after Aisha's birthday.
---

The user's girlfriend is named Aisha. Her birthday is on March 5, and she is turning 30 in 2026. They usually do one joint celebration on the weekend, but the user's shifts as a nurse at TTSH affect their weekend availability. The user booked a pottery class at a studio in Jalan Besar for Aisha on Saturday, March 7, and is looking for a Peranakan restaurant nearby that takes reservations for two. The user's March roster usually comes out in mid-February, and it has come out for 2026. The user is on night shift the week after Aisha's birthday.
