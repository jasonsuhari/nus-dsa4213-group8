---
name: sertraline-started-md
description: The user started taking sertraline two weeks ago and is off alcohol while on the antidepressants.
---

The user started taking sertraline two weeks ago and is off alcohol while on the antidepressants.
