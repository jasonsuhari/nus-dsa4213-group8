---
name: mental-health-md
description: User's mental health treatment and dietary restrictions
---

User is off alcohol while on antidepressants. User is lactose intolerant.
