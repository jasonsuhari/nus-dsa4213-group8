---
name: work-md
description: User's current job and projects as a junior architect, and cessation efforts, including gum use.
---

User is a junior architect at a small firm in Tanjong Pagar. User is currently working on drawings for a condo clubhouse. The project is at the design development stage. The client changes the pool shape every week. URA submission for the clubhouse is due Friday. User's boss wants three facade options by tomorrow. User has chosen timber, perforated metal, and a green wall as options for the facade. User is chewing mint gum non-stop at the office now. Every time the client emails, user reaches for the gum instead of going downstairs.
