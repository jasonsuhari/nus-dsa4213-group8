---
name: family
description: User's family relationships and significant events.
---

User's mum turns 65 next week. User will check out Chinatown this weekend for a jade bracelet.
