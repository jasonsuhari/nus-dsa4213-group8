---
name: wedding
description: User's wedding plans and details about the banquet, including guest list considerations.
---

User booked their wedding banquet at Parkroyal Collection Pickering for 30 tables. Alicia cried when they saw the ballroom. User's mum wants to invite her entire church choir.
