---
name: home
description: User's home life and activities during National Day.
---

User spent National Day at home with Alicia and their cat Kopi, watching the parade on TV. Kopi hates the fireworks.
