---
name: health
description: User's hobbies and interests in Gundam models.
---

User finished their Master Grade Zaku model last night. Gundam models are the only thing that calms their brain.
