---
name: wedding-banquet
description: The user booked their wedding banquet at Parkroyal Collection Pickering for 30 tables.
---

The user booked their wedding banquet at Parkroyal Collection Pickering, 30 tables. Alicia cried when they saw the ballroom.
