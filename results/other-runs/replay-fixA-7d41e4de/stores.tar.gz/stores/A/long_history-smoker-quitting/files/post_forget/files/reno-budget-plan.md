---
name: reno-budget-plan
description: The user needs a renovation budget plan for their new BTO with a budget of about $45k for a 4-room.
---

The user needs a renovation budget plan for their new BTO with a budget of about $45k for a 4-room.
