---
name: current-project
description: The user has a URA submission for the clubhouse due on Friday and needs to provide three facade options by tomorrow.
---

The user has a URA submission for the clubhouse due on Friday. The user needs to provide three facade options by tomorrow: timber, perforated metal, and a green wall.
