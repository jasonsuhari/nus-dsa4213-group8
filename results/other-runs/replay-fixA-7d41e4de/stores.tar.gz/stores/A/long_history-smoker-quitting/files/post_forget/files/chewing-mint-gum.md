---
name: chewing-mint-gum
description: The user chews mint gum non-stop at the office.
---

The user is chewing mint gum non-stop at the office now. Every time the client emails, the user reaches for the gum instead of going downstairs.
