---
name: national-day-celebration
description: The user spent National Day at home with Alicia and their cat Kopi, watching the parade on TV.
---

The user spent National Day at home with Alicia and their cat Kopi, watching the parade on TV.
