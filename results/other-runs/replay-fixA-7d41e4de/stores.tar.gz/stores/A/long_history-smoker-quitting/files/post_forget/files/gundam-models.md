---
name: gundam-models
description: The user finds building Gundam models calming for their brain.
---

The user finished their Master Grade Zaku last night. Gundam models are the only thing that calms their brain.
