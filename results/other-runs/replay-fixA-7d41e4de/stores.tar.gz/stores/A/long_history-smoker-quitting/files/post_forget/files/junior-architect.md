---
name: junior-architect
description: The user is a junior architect at a small firm in Tanjong Pagar.
---

The user is a junior architect at a small firm in Tanjong Pagar.
