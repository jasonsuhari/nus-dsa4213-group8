---
name: kopi-fireworks
description: Kopi, the user's cat, hates fireworks.
---

Kopi hates the fireworks.
