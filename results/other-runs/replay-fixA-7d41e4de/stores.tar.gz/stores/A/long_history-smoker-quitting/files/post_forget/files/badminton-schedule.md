---
name: badminton-schedule
description: The user plays badminton with the office gang every Wednesday at Toa Payoh.
---

The user plays badminton with the office gang every Wednesday at Toa Payoh.
