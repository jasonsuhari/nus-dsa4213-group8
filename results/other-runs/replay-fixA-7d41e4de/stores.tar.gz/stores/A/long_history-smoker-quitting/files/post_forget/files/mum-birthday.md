---
name: mum-birthday
description: The user's mum turns 65 next week and the user is considering a jade bracelet as a gift. The user will check out Chinatown this weekend. The user's mum wants to invite her entire church choir to the wedding.
---

The user's mum turns 65 next week. The user is thinking of a jade bracelet as a gift. The user will check out Chinatown this weekend. The user's mum wants to invite her entire church choir to the wedding.
