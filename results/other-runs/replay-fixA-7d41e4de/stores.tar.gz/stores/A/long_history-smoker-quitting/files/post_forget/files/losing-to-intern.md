---
name: losing-to-intern
description: The user keeps losing to their 22-year-old intern in badminton.
---

The user keeps losing to their intern, who is 22 and never gets tired.
