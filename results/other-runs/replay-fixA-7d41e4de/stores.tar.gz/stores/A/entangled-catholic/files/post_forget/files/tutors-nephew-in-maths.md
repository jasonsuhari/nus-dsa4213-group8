---
name: tutors-nephew-in-maths
description: The user tutors their nephew Ethan in P5 maths at their sister's place in Bukit Timah after Mass, focusing on fractions and ratio, and he dislikes word problems.
---

The user tutors their nephew Ethan in P5 maths at their sister's place in Bukit Timah after attending Mass. He struggles with fractions and ratio, and he hates word problems.
