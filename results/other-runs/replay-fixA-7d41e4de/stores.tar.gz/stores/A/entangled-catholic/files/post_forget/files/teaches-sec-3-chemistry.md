---
name: teaches-sec-3-chemistry
description: The user teaches Sec 3 chemistry and has a lesson observation on 12 February.
---

The user teaches Sec 3 chemistry and has a lesson observation on 12 February.
