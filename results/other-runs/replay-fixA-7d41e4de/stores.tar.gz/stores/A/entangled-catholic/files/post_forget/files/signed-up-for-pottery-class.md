---
name: signed-up-for-pottery-class
description: The user signed up for a pottery class on Thursday evenings.
---

The user signed up for a pottery class on Thursday evenings.
