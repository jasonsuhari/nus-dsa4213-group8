---
name: giving-up-bubble-tea-and-meat-on-fridays
description: The user is giving up bubble tea and skipping meat on Fridays for Lent.
---

The user is giving up bubble tea and skipping meat on Fridays for Lent.
