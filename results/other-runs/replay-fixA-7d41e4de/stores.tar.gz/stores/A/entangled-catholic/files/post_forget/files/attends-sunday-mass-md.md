---
name: attends-sunday-mass-md
description: The user attends 9am Mass at St Ignatius on Sunday mornings.
---

The user attends 9am Mass at St Ignatius on Sunday mornings.
