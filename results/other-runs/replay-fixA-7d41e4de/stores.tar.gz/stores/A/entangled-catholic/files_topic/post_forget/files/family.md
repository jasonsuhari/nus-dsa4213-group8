---
name: family
description: User's family relationships and tutoring details including subjects and challenges.
---

The user tutors their nephew Ethan in P5 maths. The tutoring takes place at the user's sister's place in Bukit Timah. Ethan struggles with fractions and ratio. He hates word problems.
