---
name: pottery
description: User's pottery class details including schedule.
---

The user signed up for a pottery class on Thursday evenings.
