---
name: work
description: User's profession and teaching details including observation dates.
---

The user teaches Sec 3 chemistry. The user's Head of Department is observing a lesson on the iodine clock reaction on 12 February.
