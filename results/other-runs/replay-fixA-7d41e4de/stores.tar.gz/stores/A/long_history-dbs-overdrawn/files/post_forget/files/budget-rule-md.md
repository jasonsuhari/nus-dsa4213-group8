---
name: budget-rule-md
description: The user has a new budgeting rule to avoid going into the red before payday.
---

The user has a new rule: no more going into the red before payday.
