---
name: work-schedule-md
description: The user's rent payment is deducted on the 1st of each month and their phone and transport costs are prioritized in their budget.
---

The user's rent payment is deducted on the 1st of each month. The user's phone and transport costs are prioritized in their budget.
