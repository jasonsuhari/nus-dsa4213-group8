---
name: cracked-iphone-screen
description: The user cracked their iPhone 13 screen and is considering repair options.
---

The user cracked their iPhone 13 screen. They are considering whether to repair it at Apple or a third-party shop at Sim Lim.
