---
name: tutoring-aisyah
description: The user is tutoring their younger sister Aisyah in maths on Sunday nights.
---

The user is tutoring their younger sister Aisyah in maths on Sunday nights.
