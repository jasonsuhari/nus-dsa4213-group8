---
name: assistant-manager-sneaker-store
description: The user is the assistant manager at a sneaker store in Orchard and receives a staff discount. They might get promoted to store manager in July after hitting their sales target this month, which is currently at 82%.
---

The user is the assistant manager at a sneaker store in Orchard and receives a staff discount. They might get promoted to store manager in July after hitting their sales target this month, which is currently at 82%.
