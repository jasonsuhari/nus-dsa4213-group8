---
name: budget-spreadsheet
description: The user made a budget spreadsheet this weekend that includes $150 for fun money.
---

The user made a budget spreadsheet this weekend that includes $150 for fun money.
