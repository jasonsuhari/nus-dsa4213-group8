---
name: valorant-ranked-gold
description: The user achieved Gold rank in Valorant after three months of playing and mains Jett.
---

The user finally hit Gold in Valorant ranked. It took them three months. They main Jett.
