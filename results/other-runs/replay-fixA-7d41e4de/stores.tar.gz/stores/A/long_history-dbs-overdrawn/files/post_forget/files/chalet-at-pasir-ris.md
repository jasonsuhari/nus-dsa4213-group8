---
name: chalet-at-pasir-ris
description: The user organized a chalet at Pasir Ris with friends and paid first, currently owed $85.
---

The user organized a chalet at Pasir Ris with the boys. They paid first and are owed $85, which the friends are settling up with them over PayLah.
