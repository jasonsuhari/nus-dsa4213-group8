---
name: nasi-lemak-sambal
description: The user is trying to recreate their mum's nasi lemak sambal, which currently tastes flat and they are too impatient with the frying.
---

The user is trying to recreate their mum's nasi lemak sambal. Their version tastes flat. Mum says the user is too impatient with the frying.
