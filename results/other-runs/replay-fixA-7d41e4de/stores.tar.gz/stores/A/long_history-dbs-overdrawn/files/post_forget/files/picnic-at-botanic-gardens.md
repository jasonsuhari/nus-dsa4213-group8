---
name: picnic-at-botanic-gardens
description: The user considers a picnic at the Botanic Gardens for Valentine's Day and will bring mango sticky rice from a Thai place in Golden Mile.
---

The user is considering a picnic at the Botanic Gardens for Valentine's Day and will bring mango sticky rice from a Thai place in Golden Mile.
