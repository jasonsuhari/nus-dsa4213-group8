---
name: valentines-day-plans
description: The user plans to spend Valentine's Day with Nadia on a budget and will bring mango sticky rice from a Thai place in Golden Mile.
---

The user is spending Valentine's Day with Nadia on a budget and will bring mango sticky rice from a Thai place in Golden Mile.
