---
name: travel
description: User's travel plans with Nadia to Bali for five days in October.
---

User plans to go to Bali with Nadia in October for five days. They are considering Ubud for rice terraces and quiet, or Canggu for beaches and cafes.
