---
name: running
description: User's running plans for the Sundown Marathon.
---

User signed up for the 10K at Sundown Marathon in May. User hasn't run since NS. User plans to run three times a week, building up slowly.
