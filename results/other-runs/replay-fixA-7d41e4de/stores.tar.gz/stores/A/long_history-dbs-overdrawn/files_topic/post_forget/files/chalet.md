---
name: chalet
description: User's chalet experience at Pasir Ris with friends.
---

User went to a chalet at Pasir Ris with friends. User paid first and is owed $85, which the friends are settling up via PayLah.
