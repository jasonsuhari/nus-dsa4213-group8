---
name: cooking
description: User's cooking experiences and attempts, including recipes and challenges.
---

User is trying to recreate their mum's nasi lemak sambal. User's sambal tastes flat. User's mum says they are too impatient with the frying.
