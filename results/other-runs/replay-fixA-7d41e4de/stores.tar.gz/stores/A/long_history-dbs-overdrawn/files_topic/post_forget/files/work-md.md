---
name: work-md
description: User's job details as an assistant manager at a sneaker store with perks and financial situation, including budgeting and promotion prospects.
---

User is the assistant manager at a sneaker store in Orchard. Weekends are busy, and user is on their feet for ten hours. The staff discount is the only perk. User made a budget spreadsheet this weekend. New rule: no more going into the red before payday. User's fixed costs are rent, phone, transport, and then food. Fun money is $150. Area manager hinted user might get promoted to store manager in July. User hit their sales target this month, reaching 82%.
