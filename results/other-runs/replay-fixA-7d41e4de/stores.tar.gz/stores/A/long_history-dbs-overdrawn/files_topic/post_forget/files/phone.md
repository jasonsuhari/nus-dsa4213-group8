---
name: phone
description: User's phone details and repair considerations.
---

User cracked their iPhone 13 screen. User is considering whether to repair it at Apple or a third-party shop at Sim Lim.
