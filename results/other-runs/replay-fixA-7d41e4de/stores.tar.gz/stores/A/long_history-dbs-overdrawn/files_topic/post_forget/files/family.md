---
name: family
description: User's family details, including siblings and tutoring.
---

User has a younger sister named Aisyah. Aisyah is doing her O-levels this year. User is tutoring Aisyah in maths on Sunday nights.
