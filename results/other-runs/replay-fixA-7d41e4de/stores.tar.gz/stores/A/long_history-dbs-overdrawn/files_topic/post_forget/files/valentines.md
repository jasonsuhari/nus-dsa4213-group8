---
name: valentines
description: User's Valentine's Day plans with Nadia.
---

User is spending Valentine's Day with Nadia on a budget. They are considering a picnic at the Botanic Gardens. User will bring mango sticky rice from a Thai place in Golden Mile.
