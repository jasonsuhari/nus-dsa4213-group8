---
name: gaming
description: User's gaming achievements and preferences, including Valorant.
---

User finally hit Gold in Valorant ranked. It took them three months. User mains Jett.
