---
name: user-devils-curry-recipe
description: The user makes devil's curry for family lunch.
---

The user is making devil's curry for family lunch on Sunday, feeding 20 people.
