---
name: keto-diet-start-date-md
description: The user has lost 7kg since starting a new diet.
---

The user has lost 7kg since starting a new diet.
