---
name: user-karaoke-preference
description: The user sings Elvis songs at karaoke with old schoolmates from St Patrick's, including 'Suspicious Minds' as a crowd favourite.
---

The user sings Elvis songs at karaoke with old schoolmates from St Patrick's, including 'Suspicious Minds' as a crowd favourite.
