---
name: user-daughter-name
description: The user's daughter Natalie has given birth to a daughter named Isabel weighing 3.2kg.
---

The user's daughter Natalie has given birth to a daughter named Isabel weighing 3.2kg.
