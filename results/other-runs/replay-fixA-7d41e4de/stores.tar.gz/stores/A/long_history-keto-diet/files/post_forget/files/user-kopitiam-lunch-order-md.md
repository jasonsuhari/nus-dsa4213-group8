---
name: user-kopitiam-lunch-order-md
description: The user needs a new belt after losing weight.
---

The user had to punch new holes in their belt after losing weight.
