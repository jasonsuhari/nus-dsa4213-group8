---
name: user-old-radio-restoration
description: The user is restoring an old Grundig radio from the 1960s found at a karung guni.
---

The user is restoring an old Grundig radio from the 1960s. They found it at a karung guni.
