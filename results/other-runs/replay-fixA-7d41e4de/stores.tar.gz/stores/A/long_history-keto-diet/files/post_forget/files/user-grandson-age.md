---
name: user-grandson-age
description: The user went fishing at Changi Point jetty on February 8, 2026 and caught a 2kg grouper using squid for bait.
---

The user went fishing at Changi Point jetty on February 8, 2026. They caught a 2kg grouper using squid for bait, as the uncles suggested, and had a good chat with the regulars.
