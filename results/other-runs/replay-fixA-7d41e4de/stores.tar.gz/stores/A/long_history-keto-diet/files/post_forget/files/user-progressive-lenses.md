---
name: user-progressive-lenses
description: The user needs progressive lenses now as per the optician's advice.
---

The user needs progressive lenses now as per the optician's advice.
