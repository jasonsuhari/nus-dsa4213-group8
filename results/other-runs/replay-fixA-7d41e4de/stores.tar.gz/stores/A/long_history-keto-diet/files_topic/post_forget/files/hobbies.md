---
name: hobbies
description: User's hobbies and interests, including restoration projects.
---

User is restoring an old Grundig radio from the 1960s. User found the radio at a karung guni.
