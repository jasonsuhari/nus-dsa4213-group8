---
name: health-md
description: User's health-related information and goals, including work-related stress and hobbies.
---

User needs to lose weight. User's daughter Natalie is bringing grandson Lucas over this weekend. User is experiencing a tender evaluation week at work. User went fishing at Changi Point jetty on February 8, 2026. User caught nothing but had a good chat with the regulars. User uses prawns as bait when fishing. The uncles say squid is better. User switched to squid and caught a 2kg grouper at Changi. Natalie's expecting her second child in August. User ordered chicken without rice and an extra egg for lunch at a kopitiam. User is making devil's curry for a family lunch on Sunday, feeding 20. User has lost 7kg since January and had to punch new holes in their belt. User is going to karaoke tonight with old schoolmates from St Patrick's and always sings Elvis. Natalie's daughter Isabel was born on August 26, 2026, weighing 3.2kg.
