---
name: vision
description: User's vision-related information and needs.
---

User needs progressive lenses.
