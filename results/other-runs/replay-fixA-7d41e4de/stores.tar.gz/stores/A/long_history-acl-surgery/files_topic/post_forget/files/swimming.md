---
name: swimming
description: User's daughter's swimming lessons and progress.
---

User signed their daughter Chloe up for swimming lessons on Saturday mornings at Tampines Hub. Chloe is 6 years old and scared of putting her face in the water.
