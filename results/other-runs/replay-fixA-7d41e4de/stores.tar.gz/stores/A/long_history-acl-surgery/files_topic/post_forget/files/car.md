---
name: car
description: User's car details and servicing schedule.
---

User has a Honda Vezel. User's Honda Vezel is due for its 60,000km servicing.
