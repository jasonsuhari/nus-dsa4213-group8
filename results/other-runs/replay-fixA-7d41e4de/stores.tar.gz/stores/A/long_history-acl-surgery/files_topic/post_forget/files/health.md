---
name: health
description: User's health details and physiotherapy schedule.
---

User has physiotherapy twice a week at Changi General. User's physiotherapist is named Farah. Farah is strict and makes the user do leg presses and balance work until they are shaking. User can finally walk without the brace.
