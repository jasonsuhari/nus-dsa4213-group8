---
name: hobbies
description: User's cooking activities and preferences.
---

User is attempting laksa from scratch this weekend. User is considering whether to make the rempah themselves or buy the paste. User has decided to make the rempah from scratch.
