---
name: work
description: User's job details as a logistics manager, including current projects.
---

User is a logistics manager at a shipping company in Tuas. User commutes from Tampines. User drives to work and leaves at 6:30 AM to avoid traffic on the PIE. User is coordinating the migration of the whole warehouse system to SAP by June. User has drafted a cutover plan.
