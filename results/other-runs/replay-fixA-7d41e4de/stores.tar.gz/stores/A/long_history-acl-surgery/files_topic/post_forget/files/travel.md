---
name: travel
description: User's travel plans and passport details, including renewal status.
---

User needs to renew their passport. User applied for passport renewal today. Collection is in two weeks.
