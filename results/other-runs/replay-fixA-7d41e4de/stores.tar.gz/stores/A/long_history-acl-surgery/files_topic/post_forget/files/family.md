---
name: family
description: User's family travel plans and events.
---

User's grandma is 84 years old. Reunion dinner was at user's grandma's in Ang Mo Kio. User's grandma made pineapple tarts for 40 people. User is going to Hokkaido in December for the snow, which will be the first time for the kids.
