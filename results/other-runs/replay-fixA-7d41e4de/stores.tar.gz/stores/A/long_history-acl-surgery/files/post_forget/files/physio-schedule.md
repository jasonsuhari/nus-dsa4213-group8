---
name: physio-schedule
description: The user attends physiotherapy twice a week at Changi General.
---

The user attends physiotherapy twice a week at Changi General.
