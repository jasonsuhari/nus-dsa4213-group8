---
name: wife-birthday
description: The user's wife Mei Ling's birthday is on February 14th, the same day as Valentine's Day. The user is considering dining at Violet Oon for her birthday because she loves the dry laksa there.
---

The user's wife Mei Ling's birthday is on February 14th, the same day as Valentine's Day. The user is considering dining at Violet Oon for her birthday because she loves the dry laksa there.
