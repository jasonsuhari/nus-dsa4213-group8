---
name: physio-farah
description: The user's physiotherapist is named Farah and is strict with their exercises.
---

The user's physiotherapist is named Farah and is strict, making the user do leg presses and balance work until they are shaking.
