---
name: pour-over-coffee
description: The user has started a morning ritual of making pour-over coffee using a Hario V60 and a hand grinder.
---

The user has gotten into pour-over coffee. They bought a Hario V60 and a hand grinder, making their mornings a ritual now.
