---
name: swimming-lessons
description: The user's daughter Chloe is signed up for swimming lessons on Saturday mornings at Tampines Hub.
---

The user's daughter Chloe is 6 years old and is scared of putting her face in the water. She has signed up for swimming lessons on Saturday mornings at Tampines Hub.
