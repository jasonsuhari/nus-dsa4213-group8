---
name: logistics-manager
description: The user is a logistics manager at a shipping company in Tuas and is coordinating a migration of their warehouse system to SAP by June.
---

The user is a logistics manager at a shipping company in Tuas and is coordinating a migration of their warehouse system to SAP by June. The cutover plan is currently in draft form.
