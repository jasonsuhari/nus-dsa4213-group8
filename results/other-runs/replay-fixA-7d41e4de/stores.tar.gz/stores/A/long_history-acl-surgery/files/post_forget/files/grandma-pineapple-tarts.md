---
name: grandma-pineapple-tarts
description: The user's grandma made pineapple tarts for 40 people at 84 years old.
---

The user's grandma made pineapple tarts for 40 people at 84 years old.
