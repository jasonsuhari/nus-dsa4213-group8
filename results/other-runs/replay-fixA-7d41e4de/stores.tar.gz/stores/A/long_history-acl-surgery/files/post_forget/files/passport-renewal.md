---
name: passport-renewal
description: The user has applied to renew their passport for a trip to Hokkaido in December.
---

The user needs to renew their passport. They have applied today and will collect it in two weeks. They are going to Hokkaido in December for the snow, which will be the first time for the kids.
