---
name: grandma-reunion-dinner
description: The user's reunion dinner was at their grandma's house in Ang Mo Kio.
---

The user's reunion dinner was at their grandma's in Ang Mo Kio.
