---
name: commute
description: The user finds the drive from Tampines to Tuas challenging and leaves at 6:30 AM to avoid traffic.
---

The user finds the drive from Tampines to Tuas challenging and leaves at 6:30 AM to beat the PIE jam.
