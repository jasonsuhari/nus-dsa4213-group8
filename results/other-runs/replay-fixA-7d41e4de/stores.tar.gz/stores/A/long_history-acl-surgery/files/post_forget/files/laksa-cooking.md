---
name: laksa-cooking
description: The user is attempting to make laksa from scratch this weekend and is making the rempah themselves.
---

The user is attempting to make laksa from scratch this weekend and is making the rempah themselves.
