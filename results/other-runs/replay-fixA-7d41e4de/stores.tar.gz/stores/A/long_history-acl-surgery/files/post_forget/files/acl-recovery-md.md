---
name: acl-recovery-md
description: The user is currently recovering at home. The user cannot play futsal until August at the earliest.
---

The user is currently recovering at home. They are stuck on the sofa for a while. The user can finally walk without the brace, but the surgeon says no futsal before August at the earliest.
