---
name: skills
description: User's ongoing education and skills development, including final projects.
---

The user started a SkillsFuture course in UX design on 2026-04-21. The user feels it's weird being a student again at 44. The user's first assignment is user interviews. The user is redesigning a hawker centre ordering app for their final project. The user is testing the app on their mum. The user found that their mum hesitated everywhere during testing.
