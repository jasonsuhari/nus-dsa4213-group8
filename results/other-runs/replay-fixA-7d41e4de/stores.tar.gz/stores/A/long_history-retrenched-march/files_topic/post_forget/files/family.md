---
name: family
description: Information about the user's family and relationships.
---

The user is bringing their mum to SGH for her cataract operation on 2026-06-02. The user is making bentos for Ethan, who says canteen food is boring.
