---
name: family-trip
description: Details about the user's upcoming family trip to Phuket.
---

The user is planning a family trip to Phuket in December for a week.
