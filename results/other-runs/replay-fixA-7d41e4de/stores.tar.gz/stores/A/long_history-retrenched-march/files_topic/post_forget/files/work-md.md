---
name: work-md
description: Information about the user's work history and current employment status.
---

The user worked at the company for eight years. The user's employment ended in a 15-minute call. The user has a first interview today for a product marketing role at a logistics startup. The user has a second round interview next week. The user has a campaign story from a 2024 launch that tripled sign-ups.
