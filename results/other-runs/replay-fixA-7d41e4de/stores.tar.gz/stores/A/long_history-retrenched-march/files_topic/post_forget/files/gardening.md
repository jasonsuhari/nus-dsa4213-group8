---
name: gardening
description: User's gardening activities and plants grown on their balcony.
---

The user is growing chilli padi on their balcony. The user has five chilli padi plants, and they finally have some flowers.
