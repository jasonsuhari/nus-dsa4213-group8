---
name: hobbies
description: User's hobbies and recreational activities, including pickleball tournaments.
---

The user joined a pickleball club in Bukit Timah. The user plays pickleball on Thursday mornings. The user never thought they would be into pickleball. The user's pickleball club has a doubles tournament in August. The user's partner for the tournament is a 70-year-old uncle who is better than all of them.
