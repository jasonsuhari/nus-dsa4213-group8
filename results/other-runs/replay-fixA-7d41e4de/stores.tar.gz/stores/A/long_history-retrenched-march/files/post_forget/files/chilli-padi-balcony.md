---
name: chilli-padi-balcony
description: User is growing chilli padi on their balcony with five plants that have flowers.
---

User is growing chilli padi on their balcony. They have five plants, and finally, some flowers.
