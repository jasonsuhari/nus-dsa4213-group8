---
name: skillsfuture-course-ux-design
description: User started a SkillsFuture course in UX design at age 44 and feels weird being a student again. User's final project is redesigning a hawker centre ordering app, testing it on their mum.
---

User started a SkillsFuture course in UX design today. Weird being a student again at 44. User's final project is redesigning a hawker centre ordering app, testing it on their mum.
