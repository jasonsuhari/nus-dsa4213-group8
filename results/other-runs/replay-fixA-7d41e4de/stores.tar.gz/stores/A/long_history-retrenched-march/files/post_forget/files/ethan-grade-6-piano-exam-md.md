---
name: ethan-grade-6-piano-exam-md
description: Ethan has his Grade 6 piano exam in April. Ethan finds canteen food boring and prefers bentos.
---

Ethan has his Grade 6 piano exam in April. Ethan finds canteen food boring and prefers bentos.
