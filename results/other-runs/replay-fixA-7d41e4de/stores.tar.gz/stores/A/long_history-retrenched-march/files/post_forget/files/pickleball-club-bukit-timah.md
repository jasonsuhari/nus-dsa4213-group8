---
name: pickleball-club-bukit-timah
description: User joined a pickleball club in Bukit Timah that plays Thursday mornings and never thought they would be into pickleball. The club has a doubles tournament in August.
---

User joined a pickleball club in Bukit Timah, and they play Thursday mornings. User never thought they would be into pickleball. The club has a doubles tournament in August. User's partner is a 70-year-old uncle who's better than all of them.
