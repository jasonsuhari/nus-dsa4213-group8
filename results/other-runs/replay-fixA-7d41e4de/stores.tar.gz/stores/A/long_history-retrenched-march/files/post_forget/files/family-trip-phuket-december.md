---
name: family-trip-phuket-december
description: User is planning a family trip to Phuket for a week in December.
---

User is planning a family trip in December, thinking Phuket for a week.
