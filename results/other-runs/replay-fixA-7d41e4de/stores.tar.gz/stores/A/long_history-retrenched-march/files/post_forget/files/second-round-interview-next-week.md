---
name: second-round-interview-next-week
description: User has a second round interview for the product marketing role next week and has a campaign story from a 2024 launch that tripled sign-ups.
---

User has a second round interview for the product marketing role next week and has a campaign story from a 2024 launch that tripled sign-ups.
