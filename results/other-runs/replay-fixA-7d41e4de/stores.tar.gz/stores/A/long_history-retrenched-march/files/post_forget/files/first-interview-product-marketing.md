---
name: first-interview-product-marketing
description: User had their first interview in months for a product marketing role at a logistics startup.
---

User had their first interview in months today for a product marketing role at a logistics startup.
