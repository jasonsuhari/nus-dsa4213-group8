---
name: childhood-md
description: Details about the user's current residence and food preferences.
---

The user moved to Tokyo in 2025 for work. The user misses a proper laksa.
