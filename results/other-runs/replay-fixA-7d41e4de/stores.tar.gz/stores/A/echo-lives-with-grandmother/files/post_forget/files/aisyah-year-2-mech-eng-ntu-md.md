---
name: aisyah-year-2-mech-eng-ntu-md
description: Aisyah is a Year 2 mechanical engineering student at NTU. Nenek can't take spicy food anymore and insists on making kuih bangkit for Hari Raya. Aisyah's signature dish for Hari Raya is lontong.
---

The user, Aisyah, is currently in Year 2 of mechanical engineering at NTU. Nenek can't take spicy food anymore and insists on making kuih bangkit for Hari Raya. Aisyah is planning a menu for Hari Raya in two weeks, which includes rendang, lontong, sayur lodeh, and ketupat. She will keep the rendang mild for her nenek. Aisyah's signature dish for Hari Raya is lontong. Aisyah wants to take driving lessons to drive her nenek to her clinic appointments, as the bus is hard on her knees. Aisyah's classes are from Monday to Thursday. Aisyah has driving lessons on Wednesday nights from 7 to 9pm.
