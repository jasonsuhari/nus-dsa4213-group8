---
name: ruby-school-md
description: Information about Ruby's schooling and needs, and user's teaching role.
---

Ruby is starting Primary 3 on January 9, 2026. Ruby needs new school shoes. Ruby is with her dad this weekend. The user is teaching P4 at a primary school in Woodlands. The user is currently marking 38 maths worksheets, which include a focus on fractions. The user is renewing Ruby's passport for their trip to Taiwan in June. The user is having Mother's Day lunch at their mum's in Jurong West. The user is going to Taiwan in a week for five days in Taipei. Ruby wants to visit Jiufen and the night markets. Ruby will love the gondola. The user applied for the maths subject head position at school. Interview is in August. Ruby's dentist says she might need braces next year.
