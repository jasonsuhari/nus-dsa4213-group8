---
name: zumba
description: User's participation in Zumba classes.
---

The user started Zumba on Tuesday nights at the community centre. The user feels they are the worst one there but loves it. The user enjoys massages and brunch.
