---
name: book-club
description: User's participation in a book club and current reading material.
---

The user is in a book club. The book club is reading 'Pachinko' this month.
