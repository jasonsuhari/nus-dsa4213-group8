---
name: ruby-school-shoes
description: Ruby might need braces next year according to her dentist.
---

Ruby's dentist says she might need braces next year.
