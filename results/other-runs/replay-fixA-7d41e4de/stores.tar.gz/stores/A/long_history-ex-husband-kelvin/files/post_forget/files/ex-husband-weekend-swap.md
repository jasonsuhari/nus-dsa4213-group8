---
name: ex-husband-weekend-swap
description: User's ex-husband wants to swap weekends due to his company retreat and the user has asked him to confirm Ruby's pickup time.
---

My ex-husband wants to swap weekends because of his company retreat. I asked him to confirm Ruby's pickup time. Ruby is with her dad this weekend, and I finally have a Saturday to myself. The school fees split has been 50-50 since the divorce.
