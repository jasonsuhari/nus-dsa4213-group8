---
name: mother-day-lunch-jurong-west
description: User's Mother's Day lunch is at their mum's in Jurong West where she refuses to let anyone else cook.
---

User's Mother's Day lunch is at their mum's in Jurong West. Their mum refuses to let anyone else cook.
