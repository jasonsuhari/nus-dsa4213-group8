---
name: book-club-reading-pachinko
description: User's book club is reading Pachinko this month.
---

User's book club is reading Pachinko this month, which has 500 pages.
