---
name: zumba-tuesday-nights
description: The user started Zumba on Tuesday nights at the community centre and enjoys it despite feeling like the worst one there.
---

The user started Zumba on Tuesday nights at the community centre. They feel like the worst one there but love it.
