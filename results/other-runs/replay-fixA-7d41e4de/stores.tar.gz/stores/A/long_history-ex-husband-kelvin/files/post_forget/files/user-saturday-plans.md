---
name: user-saturday-plans
description: User's plans for the Taiwan trip including destinations and activities.
---

User's Taiwan trip is in a week. They will spend five days in Taipei with the following itinerary: Day 1 Ximending, Day 2 Jiufen and Shifen, Day 3 Taipei 101 and Raohe market, Day 4 the zoo and Maokong gondola (best on a clear day), Day 5 shopping.
