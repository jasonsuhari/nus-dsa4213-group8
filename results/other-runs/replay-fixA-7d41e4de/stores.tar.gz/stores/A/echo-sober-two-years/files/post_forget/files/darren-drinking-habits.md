---
name: darren-drinking-habits
description: Darren has triggers related to work stress, social events with drinking, certain times of day, and Friday evenings after a bad week.
---

The user, Darren, prefers no bars or wine pairings in suggestions. Darren's team is having a bonding night at a bar in Clarke Quay on 2026-03-27. He finds the drinking culture there tough. His triggers include work stress, social events with drinking, certain times of day, and Friday evenings after a bad week.
