---
name: advanced-diploma-critical-care-nursing
description: User enrolled in an advanced diploma in critical care nursing with classes starting in October, alongside their shifts.
---

User enrolled in the advanced diploma in critical care nursing. Classes start in October, alongside their shifts.
