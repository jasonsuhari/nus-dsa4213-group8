---
name: sara-playgroup
description: User's daughter Sara starts playgroup in July at a centre near their block in Punggol.
---

User's daughter Sara starts playgroup in July at a centre near their block in Punggol. She's never been away from the user.
