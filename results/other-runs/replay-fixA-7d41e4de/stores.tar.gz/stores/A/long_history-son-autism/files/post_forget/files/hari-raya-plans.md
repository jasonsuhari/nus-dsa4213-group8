---
name: hari-raya-plans
description: User is on beef rendang duty for Hari Raya at their mum's in Tampines.
---

User is on beef rendang duty, preparing 3kg of beef for Hari Raya at their mum's in Tampines.
