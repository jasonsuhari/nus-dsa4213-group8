---
name: mazda-coe-expiration
description: User's Mazda 3 COE expires next year.
---

The COE for the user's Mazda 3 expires next year.
