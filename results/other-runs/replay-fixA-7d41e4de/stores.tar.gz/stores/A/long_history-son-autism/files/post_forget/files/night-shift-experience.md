---
name: night-shift-experience
description: User works night shifts as a nurse at Sengkang General and has to swap shifts for Irfan's therapy.
---

The user is a nurse at Sengkang General and has done four nights in a row. Irfan's occupational therapy at KKH moved to Wednesdays, so the user has to swap shifts.
