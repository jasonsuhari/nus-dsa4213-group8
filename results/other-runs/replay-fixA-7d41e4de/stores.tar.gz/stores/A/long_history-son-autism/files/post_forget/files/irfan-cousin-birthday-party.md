---
name: irfan-cousin-birthday-party
description: Irfan's cousin's birthday party is on Sunday, and his sister set up a quiet corner for him.
---

Irfan's cousin's birthday party is on Sunday. His sister already set one up for him.
