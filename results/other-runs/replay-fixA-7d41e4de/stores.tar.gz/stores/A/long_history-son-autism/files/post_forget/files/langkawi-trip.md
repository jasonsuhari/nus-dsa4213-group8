---
name: langkawi-trip
description: User is booking a trip to Langkawi in December for their family.
---

User is booking Langkawi for December, just the four of them.
