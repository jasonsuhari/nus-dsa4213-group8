---
name: irfan-autism-md
description: User's son Irfan loves trains and is autistic, and his occupational therapy at KKH is on Wednesdays. He has noise-cancelling headphones for loud environments and knows every station on the Thomson-East Coast Line.
---

User's son Irfan is autistic, loud places are hard for him, and he loves trains. Irfan's occupational therapy at KKH moved to Wednesdays. He uses noise-cancelling headphones to help manage noise. Irfan made the user ride the whole Thomson-East Coast Line end to end on Saturday, and he knew every station.
