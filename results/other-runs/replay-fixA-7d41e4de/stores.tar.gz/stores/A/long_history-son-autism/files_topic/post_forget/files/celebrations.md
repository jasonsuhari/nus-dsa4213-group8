---
name: celebrations
description: User's celebrations and food duties during events.
---

User celebrates Hari Raya at their mum's in Tampines. User is on beef rendang duty, preparing 3kg of beef.
