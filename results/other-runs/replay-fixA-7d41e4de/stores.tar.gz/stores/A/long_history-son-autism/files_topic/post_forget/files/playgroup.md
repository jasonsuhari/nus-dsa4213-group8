---
name: playgroup
description: User's details about Sara's playgroup attendance.
---

Sara starts playgroup in July at a centre near their block in Punggol. She's never been away from the user.
