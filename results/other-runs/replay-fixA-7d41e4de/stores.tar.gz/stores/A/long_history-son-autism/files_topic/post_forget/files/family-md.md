---
name: family-md
description: User's family details and events.
---

User has a son named Irfan. Loud places are hard for Irfan. Irfan loves trains. Irfan's occupational therapy at KKH moved to Wednesdays. Irfan's cousin's birthday party is on Sunday. Irfan's sister set up a quiet corner for him at the birthday party. Irfan made the user ride the whole Thomson-East Coast Line end to end on Saturday. Irfan knew every station.
