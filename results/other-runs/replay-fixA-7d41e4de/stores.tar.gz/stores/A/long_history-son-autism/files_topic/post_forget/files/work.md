---
name: work
description: User's job details as a nurse and education.
---

User is a nurse at Sengkang General. User has done four night shifts in a row. User has to swap shifts to accommodate Irfan's occupational therapy on Wednesdays. User enrolled in the advanced diploma in critical care nursing. Classes start in October. User will do the diploma alongside their shifts.
