---
name: travel
description: User's travel plans and destinations.
---

User is booking a trip to Langkawi in December for their family.
