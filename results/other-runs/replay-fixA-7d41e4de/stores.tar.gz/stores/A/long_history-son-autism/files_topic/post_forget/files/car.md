---
name: car
description: User's car details and decisions.
---

User has a Mazda 3. The COE for the Mazda 3 expires next year.
