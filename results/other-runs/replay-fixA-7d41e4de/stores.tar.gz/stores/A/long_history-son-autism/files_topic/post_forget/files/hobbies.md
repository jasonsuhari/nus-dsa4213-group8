---
name: hobbies
description: User's hobbies and crafting activities including crocheting and amigurumi.
---

User started crocheting a blanket for Sara. User has completed Sara's blanket. User plans to start amigurumi next, maybe a little train for Irfan.
