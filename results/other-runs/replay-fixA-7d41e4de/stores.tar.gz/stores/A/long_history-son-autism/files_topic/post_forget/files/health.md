---
name: health
description: User's health and sleep habits.
---

User uses blackout curtains to help with sleep. User maintains the same sleep time after each shift.
