---
name: hakim-md
description: User's indoor rowing challenge
---

They are skipping the hall's cross-country run on the 1st and doing the indoor rowing challenge instead.
