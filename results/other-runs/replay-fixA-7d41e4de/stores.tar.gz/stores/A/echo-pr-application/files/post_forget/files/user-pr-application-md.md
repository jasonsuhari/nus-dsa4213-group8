---
name: user-pr-application-md
description: The user is considering changing jobs.
---

The user is considering changing jobs while the PR application is pending.
