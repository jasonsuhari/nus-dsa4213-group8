---
name: logistics-coordinator-md
description: The user is a logistics coordinator at a shipping firm in Tuas.
---

The user is a logistics coordinator at a shipping firm in Tuas. The user has cancelled their Japan trip in December 2026 and is selling their PS5 to pay down their credit card. The user is working on a plan to clear their credit card debt. The user has done two NCPG counselling sessions and blocked all the betting sites on their phone.
