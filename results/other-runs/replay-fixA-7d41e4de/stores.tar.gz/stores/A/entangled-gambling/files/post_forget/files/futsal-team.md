---
name: futsal-team
description: The user joined a futsal team that plays Saturday nights at Kallang.
---

The user joined a futsal team that plays Saturday nights at Kallang, which keeps them busy when the matches are on.
