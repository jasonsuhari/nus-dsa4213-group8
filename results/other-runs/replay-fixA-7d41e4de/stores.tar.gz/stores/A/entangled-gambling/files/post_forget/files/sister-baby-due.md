---
name: sister-baby-due
description: The user is going to be an uncle as their sister Anjali's baby is due in September.
---

The user's sister Anjali's baby is due in September, making the user an uncle.
