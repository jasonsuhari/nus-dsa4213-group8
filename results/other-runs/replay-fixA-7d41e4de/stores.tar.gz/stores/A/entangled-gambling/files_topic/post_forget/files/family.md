---
name: family
description: User's family relationships and upcoming events
---

User's sister Anjali's baby is due in September. User is going to be an uncle.
