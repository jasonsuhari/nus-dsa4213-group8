---
name: gambling-md
description: User's gambling problem and efforts to manage it
---

User has lost about $8,000 on online football betting since January. User has cancelled a trip to Japan in December. User is selling their PS5 to pay down their credit card. User has done two NCPG counselling sessions. User has blocked all the betting sites on their phone.
