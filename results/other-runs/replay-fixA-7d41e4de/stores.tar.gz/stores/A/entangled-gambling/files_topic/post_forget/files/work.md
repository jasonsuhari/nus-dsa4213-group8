---
name: work
description: User's job as a logistics coordinator at a shipping firm
---

User is a logistics coordinator at a shipping firm in Tuas.
