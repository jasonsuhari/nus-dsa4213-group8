---
name: futsal
description: User's involvement in a futsal team
---

User joined a futsal team that plays Saturday nights at Kallang.
