---
name: family-md
description: Information about the user's commuting habits, children's school, and family trips.
---

The user has stopped carpooling with their colleague Farah since their new office is in Changi Business Park. The twins attend Temasek Primary School, which starts at 7:30. The user is thinking of a family road trip to Malacca in the September school holidays. The user needs to sort out charging for the Tesla on the way. The user's wife, Grace, wants a stay near Jonker Street. Grace also wants to try the chicken rice balls.
