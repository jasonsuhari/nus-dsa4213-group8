---
name: twins-age
description: The user has stopped carpooling with their colleague Farah due to a new office location.
---

The user is hosting the twins' birthday party at their condo function room in Bedok. The user has stopped carpooling with their colleague Farah since their new office is in Changi Business Park.
