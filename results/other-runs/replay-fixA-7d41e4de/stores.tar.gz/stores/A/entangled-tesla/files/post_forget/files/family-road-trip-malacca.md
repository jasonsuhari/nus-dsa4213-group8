---
name: family-road-trip-malacca
description: The user is planning a family road trip to Malacca during the September school holidays and Grace wants to try the chicken rice balls.
---

The user is thinking of a family road trip to Malacca in the September school holidays. Grace wants to try the chicken rice balls.
