---
name: twins-names
description: The user has twins named Chloe and Caleb who attend Temasek Primary.
---

The user has twins named Chloe and Caleb. The user will drop the twins at Temasek Primary on the way to their new office.
