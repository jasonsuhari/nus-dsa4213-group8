---
name: twins-interests
description: The user’s twins are obsessed with dinosaurs.
---

The user’s twins, Chloe and Caleb, are obsessed with dinosaurs.
