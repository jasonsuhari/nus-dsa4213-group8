---
name: stay-near-jonker-street
description: The user's wife wants to stay near Jonker Street in Malacca.
---

The user's wife wants a stay near Jonker Street.
