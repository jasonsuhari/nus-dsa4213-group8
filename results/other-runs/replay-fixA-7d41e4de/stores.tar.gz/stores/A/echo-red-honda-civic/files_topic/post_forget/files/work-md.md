---
name: work-md
description: Information about the user's job as a pharma sales rep, including a recent incident, their dog, car rental needs, a friend's wedding, wedding details, considerations about COE renewal and switching to an EV, and the user's monthly mileage.
---

The user is a pharma sales rep. The COE for the user's car expires in March 2028, and they are considering whether to renew or switch to an EV. Someone scratched the user's car at the Sengkang Grand Mall carpark, leaving a long scratch on the passenger door. The user's golden retriever, Biscuit, was in the car during the incident and was upset. The workshop needs the user's car for 3 days, and the user is looking to rent a car similar to theirs for comfort. The user needs the rental car for clinic rounds in Jurong on Thursday. The user is going to a friend's wedding at Capella Sentosa on 5 September and needs to send their car make and colour for valet. The user does around 2,500km a month.
