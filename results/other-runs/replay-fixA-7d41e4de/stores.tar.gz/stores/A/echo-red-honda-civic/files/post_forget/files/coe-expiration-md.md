---
name: coe-expiration-md
description: User's COE expiration details for their car and considerations about renewing or switching to an EV based on their mileage.
---

The user's COE expires in March 2028, and they are considering whether to renew or switch to an electric vehicle (EV). The user drives around 2,500 km a month.
