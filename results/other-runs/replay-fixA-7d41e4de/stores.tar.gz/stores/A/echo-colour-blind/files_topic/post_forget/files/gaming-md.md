---
name: gaming-md
description: User's gaming interests and preferences, including monitor budget and color-blind mode usage.
---

The user is thinking of buying a new monitor for gaming. The user mostly plays Valorant. The user's budget for a new monitor is $600.
