---
name: valorant-md
description: User mostly plays Valorant and uses the deuteranopia colour-blind mode for clearer enemy highlights.
---

The user plays Valorant mostly and already uses the deuteranopia colour-blind mode for clearer enemy highlights.
