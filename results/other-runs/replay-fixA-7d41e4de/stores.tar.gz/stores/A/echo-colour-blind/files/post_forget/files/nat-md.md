---
name: nat-md
description: User has a wardrobe limited to navy, grey, white, and black. User got a senior analyst job at Grab that requires a medical check.
---

Their whole wardrobe now consists of navy, grey, white, and black. They got a senior analyst job at Grab that requires a medical check.
