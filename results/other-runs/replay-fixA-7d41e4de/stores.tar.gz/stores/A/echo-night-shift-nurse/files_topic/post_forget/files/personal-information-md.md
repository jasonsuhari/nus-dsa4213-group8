---
name: personal-information-md
description: Basic personal information about the user, including family details.
---

The user is Priya. The user is 29 years old. The user lives in Bedok. The user has a younger sister named Kavya. Kavya is getting married on 21 November and the user is the maid of honour. Kavya wants the user to give a speech at the wedding. The user is off work the weekend of 14 March. The user is planning a hen party brunch for Kavya on 14 March. The user and Kavya grew up in Ipoh.
