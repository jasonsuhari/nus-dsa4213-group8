---
name: user-job-md
description: The user's job and work schedule, including effects on sleep and work pattern.
---

The user is an ICU nurse. The user's work hours are wrecking her sleep.
