---
name: address-md
description: Wei Jie's new address for deliveries and correspondence, and information about Wei Jie's mum's address.
---

Wei Jie's mum lives in Jurong West, Block 652. Wei Jie swims at Our Tampines Hub before visiting his mum.
