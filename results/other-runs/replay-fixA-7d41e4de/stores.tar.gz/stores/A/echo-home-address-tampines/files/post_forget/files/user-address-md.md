---
name: user-address-md
description: User's new address for deliveries
---

The user has moved to a new place. The user's address for deliveries is Singapore 520412. The user is ordering a PAX wardrobe, 150cm wide.
