---
name: travel
description: User's fitness activities and events, including marathon participation and training plans.
---

User signed up for the Standard Chartered half marathon in December. User is a slow runner and needs a training plan. User plans to run three times a week: one easy run, one tempo run, and a long run on weekends, building up to 18km.
