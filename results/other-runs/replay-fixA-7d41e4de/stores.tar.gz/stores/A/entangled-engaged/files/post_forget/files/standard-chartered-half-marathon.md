---
name: standard-chartered-half-marathon
description: User signed up for the Standard Chartered half marathon in December and is a slow runner needing a training plan.
---

The user signed up for the Standard Chartered half marathon in December and is a slow runner, so they need a training plan.
