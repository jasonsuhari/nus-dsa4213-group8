---
name: user-interests-md
description: User's interest in spa activities and need for rest due to being a senior staff nurse.
---

The user is interested in spa activities and is a senior staff nurse at KK Hospital, so they really need the rest.
