---
name: bto-flats-tengah-md
description: User is looking at BTO flats in Tengah for the November launch.
---

The user and their boyfriend Daniel are looking at BTO flats in Tengah for the November launch.
