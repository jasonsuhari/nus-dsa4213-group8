---
name: mum-tea-ceremony-rom-date-md
description: User's mum is asking about a tea ceremony and a ROM date.
---

The user's mum is already asking about a tea ceremony and a ROM date.
