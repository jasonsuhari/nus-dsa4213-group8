---
name: fiancee-scheme-md
description: User can apply for BTO flats under the fiancé/fiancée scheme with Daniel.
---

They can apply for BTO flats under the fiancé/fiancée scheme with Daniel.
