---
name: boyfriend-interests
description: User's boyfriend is into surfing.
---

The user's boyfriend, Daniel, is into surfing.
