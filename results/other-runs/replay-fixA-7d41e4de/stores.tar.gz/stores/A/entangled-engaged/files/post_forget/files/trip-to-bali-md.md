---
name: trip-to-bali-md
description: User's trip to Bali with boyfriend Daniel from 24 to 28 September.
---

The user and their boyfriend Daniel went to Bali from 24 to 28 September, and on their last night there, Daniel proposed.
