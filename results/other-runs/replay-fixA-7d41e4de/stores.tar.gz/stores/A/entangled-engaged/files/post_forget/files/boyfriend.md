---
name: boyfriend
description: User's boyfriend's name.
---

The user's boyfriend is named Daniel.
