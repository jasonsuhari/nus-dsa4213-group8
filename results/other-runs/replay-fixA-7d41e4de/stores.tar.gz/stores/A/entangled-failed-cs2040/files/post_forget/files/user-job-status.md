---
name: user-job-status
description: The user has dropped their part-time job at Koi.
---

The user has dropped their part-time job at Koi.
