---
name: user-education
description: The user is taking 4 modules this semester including a retake of CS2040.
---

The user is in year 2 of information systems at the National University of Singapore (NUS) and is taking 4 modules this semester including a retake of CS2040.
