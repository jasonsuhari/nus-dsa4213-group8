---
name: user-name
description: The user has joined the NUS Hackers club to code more outside class.
---

The user has joined the NUS Hackers club to code more outside class.
