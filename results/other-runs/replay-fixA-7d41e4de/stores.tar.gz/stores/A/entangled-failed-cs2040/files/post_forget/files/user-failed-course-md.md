---
name: user-failed-course-md
description: The user is retaking CS2040 this semester.
---

The user is retaking CS2040 this semester.
