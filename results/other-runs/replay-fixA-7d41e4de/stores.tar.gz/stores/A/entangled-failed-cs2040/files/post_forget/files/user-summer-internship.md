---
name: user-summer-internship
description: The user wants to apply for a summer internship at GovTech.
---

The user wants to apply for a summer internship at GovTech.
