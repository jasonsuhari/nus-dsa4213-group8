---
name: user-dad-food-preference
description: The user's dad loves Teochew food.
---

The user's dad loves Teochew food.
