---
name: user-residence
description: The user has moved into PGP House to cut their commute from Pasir Ris.
---

The user has moved into PGP House to cut their commute from Pasir Ris.
