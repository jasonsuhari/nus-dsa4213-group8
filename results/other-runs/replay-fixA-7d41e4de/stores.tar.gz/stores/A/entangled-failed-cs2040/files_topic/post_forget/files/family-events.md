---
name: family-events
description: Upcoming family events and celebrations.
---

The user's dad's 60th birthday is on 21 February. The user is booking a private room at Chui Huay Lim for 8 people.
