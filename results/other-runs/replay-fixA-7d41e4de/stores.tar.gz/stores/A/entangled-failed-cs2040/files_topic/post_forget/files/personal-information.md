---
name: personal-information
description: Basic personal information about the user and their family.
---

The user's name is Jia Hui. The user is in year 2 of information systems at NUS. The user's dad's 60th birthday is on 21 February.
