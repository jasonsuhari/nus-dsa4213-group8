---
name: academic-performance
description: User's extracurricular activities related to coding and internship plans.
---

The user joined the NUS Hackers club to code more outside class. The user wants to apply for a summer internship at GovTech.
