---
name: living-situation
description: User's current living situation and changes.
---

The user has moved into PGP House to cut their commute from Pasir Ris. The commute was 1.5 hours each way.
