---
name: work
description: User's work history and current employment status.
---

The user has dropped their part-time job at Koi.
