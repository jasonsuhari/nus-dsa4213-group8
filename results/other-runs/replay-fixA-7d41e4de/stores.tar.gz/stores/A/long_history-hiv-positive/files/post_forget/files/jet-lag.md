---
name: jet-lag
description: The user experiences jet lag due to irregular body clock.
---

Being cabin crew on long-haul flights means the user's body clock has no idea what day it is.
