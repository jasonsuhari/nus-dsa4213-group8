---
name: adopted-dog
description: The user and Ben adopted a rescue dog named Mochi, a 3-year-old Singapore Special who sleeps on Ben's side of the bed.
---

The user and Ben adopted a rescue dog named Mochi, a 3-year-old Singapore Special who sleeps on Ben's side of the bed.
