---
name: cabin-crew-long-haul
description: The user is cabin crew on long-haul flights.
---

The user is cabin crew on long-haul flights.
