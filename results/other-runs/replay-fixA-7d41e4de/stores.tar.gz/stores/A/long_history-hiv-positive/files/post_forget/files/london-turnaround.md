---
name: london-turnaround
description: The user recently returned from a London turnaround.
---

The user just back from a London turnaround.
