---
name: hiv-medication-schedule-md
description: The user has a quarterly check-up at NCID tomorrow with a blood draw at 8am.
---

The user has a quarterly check-up at NCID tomorrow, with a blood draw scheduled for 8am.
