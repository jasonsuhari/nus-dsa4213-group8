---
name: fitness-membership
description: The user has an Anytime Fitness membership in Novena that is up for renewal.
---

The user's Anytime Fitness membership in Novena is up.
