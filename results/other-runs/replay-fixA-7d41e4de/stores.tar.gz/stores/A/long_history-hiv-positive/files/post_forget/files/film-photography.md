---
name: film-photography
description: The user has a new obsession with film photography and picked up a Pentax K1000, with their first rolls developed at a lab in Peninsula Plaza.
---

The user picked up a Pentax K1000 at a flea market. Film photography is their new obsession. They got their first rolls developed at a lab in Peninsula Plaza. Half are blurry but a few of Ben are gorgeous.
