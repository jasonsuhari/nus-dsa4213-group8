---
name: sourdough-starter
description: The user has a sourdough starter named Gerald that doubled in four hours and requires frequent feeding.
---

The user's sourdough starter, Gerald, finally doubled in four hours and needs feeding more often.
