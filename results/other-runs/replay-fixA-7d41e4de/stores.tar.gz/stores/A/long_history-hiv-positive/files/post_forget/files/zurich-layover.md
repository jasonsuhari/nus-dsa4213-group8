---
name: zurich-layover
description: The user has a 24-hour layover in Zurich next week.
---

The user has a 24-hour layover in Zurich next week.
