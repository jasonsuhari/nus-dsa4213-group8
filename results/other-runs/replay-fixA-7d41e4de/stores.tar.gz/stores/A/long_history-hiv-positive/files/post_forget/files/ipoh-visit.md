---
name: ipoh-visit
description: The user is flying to Ipoh for their mum's 70th birthday and has a family dinner planned with ten tables at a Chinese restaurant.
---

The user is flying to Ipoh for their mum's 70th birthday. She still lives in the house the user grew up in. Mum invited the whole street for a family dinner at a Chinese restaurant with ten tables.
