---
name: leading-steward-training
description: The user started a training course to become a leading steward.
---

The user started the training course to become a leading steward. The course includes lots of service recovery role-plays.
