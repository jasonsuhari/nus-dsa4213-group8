---
name: work
description: User's job as cabin crew, training to become a leading steward, and its effects on their body clock, and their relationship with Ben.
---

User is cabin crew on long-haul flights. User has just returned from a London turnaround. Being cabin crew on long-haul flights means their body clock has no idea what day it is. User is starting a training course to become a leading steward, which includes lots of service recovery role-plays. User and Ben hit five years together on February 25, 2026. Ben loves Cicheti. Ben says user loves Gerald more than him. User is flying to Ipoh for their mum's 70th birthday. User has a 24-hour layover in Zurich next week.
