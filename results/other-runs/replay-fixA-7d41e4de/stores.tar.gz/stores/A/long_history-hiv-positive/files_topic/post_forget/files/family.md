---
name: family
description: User's family details and significant events, including their mum's birthday celebration.
---

User's mum is turning 70. User's mum still lives in the house they grew up in. User's mum invited the whole street to celebrate her birthday at a Chinese restaurant with ten tables.
