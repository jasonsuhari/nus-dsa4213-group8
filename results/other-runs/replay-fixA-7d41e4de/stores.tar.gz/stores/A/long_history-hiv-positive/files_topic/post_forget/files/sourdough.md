---
name: sourdough
description: User's sourdough starter named Gerald and its progress.
---

User has a sourdough starter named Gerald. Gerald finally doubled in four hours. User plans to bake bread this weekend.
