---
name: health
description: User's fitness membership options and considerations.
---

User's Anytime Fitness membership in Novena is up. User is considering whether to renew it or try ClassPass.
