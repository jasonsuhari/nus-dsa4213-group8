---
name: pets
description: User's new rescue dog, Mochi, and details about him.
---

User adopted a rescue dog named Mochi. Mochi is a 3-year-old Singapore Special. She sleeps on Ben's side of the bed already.
