---
name: latte-art-throwdown
description: The user is hosting a latte art throwdown at their café on 2 May with 8 baristas in knockout rounds.
---

The user's boss asked them to host the café's latte art throwdown on 2 May with 8 baristas participating in knockout rounds.
