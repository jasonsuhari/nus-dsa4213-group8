---
name: coffee-cart
description: The user aims to save $1,000 a month to open their own coffee cart in two years.
---

The user wants to open their own coffee cart in two years and aims to save $1,000 a month.
