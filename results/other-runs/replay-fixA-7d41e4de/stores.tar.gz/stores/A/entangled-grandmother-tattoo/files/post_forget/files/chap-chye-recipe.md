---
name: chap-chye-recipe
description: The user cooks their Ah Ma's chap chye recipe every Sunday with modifications.
---

The user cooks their Ah Ma's chap chye recipe every Sunday with modifications. Her chap chye always had lots of dried shrimp and fermented bean curd, but the user's version doesn't taste the same yet.
