---
name: barista
description: The user is a barista at a café in Joo Chiat.
---

The user is a barista at a café in Joo Chiat.
