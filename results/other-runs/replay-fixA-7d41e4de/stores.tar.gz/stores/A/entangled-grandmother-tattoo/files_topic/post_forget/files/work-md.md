---
name: work-md
description: Details about the user's work and career aspirations.
---

The user is a barista at a café in Joo Chiat. The user wants to open their own coffee cart in two years. The user will aim to save $1,000 a month for this goal. The user's boss asked them to host the café's latte art throwdown on 2 May. The throwdown will feature 8 baristas competing in knockout rounds.
