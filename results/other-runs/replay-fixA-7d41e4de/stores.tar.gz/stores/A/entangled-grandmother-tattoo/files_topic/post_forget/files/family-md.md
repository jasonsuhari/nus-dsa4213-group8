---
name: family-md
description: Details about the user's family and their memories.
---

The user's Ah Ma, Tan Siew Lan, passed away in January. The user cooks their Ah Ma's chap chye recipe every Sunday to preserve it. The user's Ah Ma's chap chye always had lots of dried shrimp and fermented bean curd.
