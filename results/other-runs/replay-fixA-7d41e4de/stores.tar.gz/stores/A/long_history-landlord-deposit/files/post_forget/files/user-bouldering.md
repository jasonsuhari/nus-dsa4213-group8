---
name: user-bouldering
description: User has completed their first V4 at the bouldering gym near their place after three weeks of attempts.
---

User finally sent their first V4 at the bouldering gym near their place after three weeks of falling off the same move.
