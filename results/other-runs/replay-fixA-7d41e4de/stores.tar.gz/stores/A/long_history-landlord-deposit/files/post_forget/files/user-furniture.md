---
name: user-furniture
description: User bought a standing desk from IKEA for their studio.
---

User bought a standing desk from IKEA for the studio. Assembly took them three hours.
