---
name: user-job
description: User is learning dbt for work to version-control SQL models.
---

User is learning dbt for work. Their manager wants their SQL models version-controlled.
