---
name: user-project
description: User is building churn dashboards in Tableau this month.
---

This month, user is building churn dashboards in Tableau and the data is a mess.
