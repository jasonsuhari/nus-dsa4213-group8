---
name: user-cricket
description: User's team won the semi-final of the weekend cricket league and they took two wickets.
---

User's team won the semi-final of the weekend cricket league. They took two wickets.
