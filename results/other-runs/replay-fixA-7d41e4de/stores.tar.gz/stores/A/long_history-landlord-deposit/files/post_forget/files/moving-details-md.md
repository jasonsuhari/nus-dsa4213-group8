---
name: moving-details-md
description: User is moving from a flat in Clementi to a studio in Kallang.
---

User is moving out of their old flat in Clementi into a studio in Kallang on the weekend of February 6, 2026. User took move-out photos of every room on the last day. User filed a claim at the Small Claims Tribunals on April 6, 2026, and the hearing is set for July 14, 2026. User is printing all their WhatsApp chats with Mr Goh and the move-out photos, putting them in a folder for July.
