---
name: cricket
description: Details about the user's cricket achievements and team participation.
---

The user plays in a weekend cricket league. The user's team won the semi-final of the weekend cricket league. The user took two wickets in the semi-final. The final is next Saturday at the Padang.
