---
name: family
description: Information about the user's parents visiting from Chennai and their interests.
---

The user's parents are visiting from Chennai in June 2026 for two weeks. This will be their first time in Singapore. The user booked them a hotel nearby because the studio is too small. The user's dad loves plants, and the user's mum loves temples.
