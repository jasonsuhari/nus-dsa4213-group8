---
name: bouldering
description: The user's bouldering achievements and experiences.
---

The user has sent their first V4 at the bouldering gym near their place. The user spent three weeks falling off the same move before achieving this.
