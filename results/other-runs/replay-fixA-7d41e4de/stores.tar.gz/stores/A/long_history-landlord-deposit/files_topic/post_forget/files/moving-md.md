---
name: moving-md
description: Details about the user's upcoming move to a new studio.
---

The user is moving out of their old flat in Clementi into a studio in Kallang this weekend. The user took move-out photos of every room on the last day. The user filed their claim at the Small Claims Tribunals on 6 April 2026. The hearing is set for 14 July 2026. The user is nervous about attending the tribunal as they have never been to one before. The user is printing all their WhatsApp chats with Mr Goh and the move-out photos, putting them in a folder for July. The user bought a standing desk from IKEA for the studio. Assembly took them three hours.
