---
name: work
description: Information about the user's job as a data analyst and learning dbt.
---

The user is a data analyst at a telco. This month, the user is building churn dashboards in Tableau and finds the data to be a mess. The user is learning dbt for work as their manager wants their SQL models version-controlled.
