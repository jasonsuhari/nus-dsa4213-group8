---
name: cooking
description: The user's cooking experiences and attempts.
---

The user is trying to make chicken biryani in the Instant Pot. The rice came out mushy.
